/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="PrivateReferences.ts"/>
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="PrivateReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var BusinessClosureListControl;
    (function (BusinessClosureListControl) {
        'use strict';
        var GridControl = (function () {
            function GridControl() {
                this.gridId = MscrmCommon.ControlUtils.ControlGuidGenerator
                    .newGuid(Constants.GRID_ID);
            }
            GridControl.prototype.init = function (context, notifyOutputChanged, state) {
                this.context = context;
                this.model = this.context.parameters.Grid;
            };
            GridControl.prototype.applyFilter = function (expression) {
                this.model.filtering.clearFilter();
                this.model.filtering.setFilter(expression);
            };
            GridControl.prototype.updateView = function (context) {
                var properties = this.createProperties();
                this.view = this.context.factory.createComponent("MscrmControls.Grid.ReadOnlyGrid", this.gridId, properties);
                return this.view;
            };
            GridControl.prototype.getOutputs = function () {
                return null;
            };
            GridControl.prototype.destroy = function () {
                this.context = null;
                this.model = null;
                this.view = null;
            };
            GridControl.prototype.createProperties = function () {
                return {
                    parameters: {
                        Grid: {
                            Type: "Grid",
                            TargetEntityType: this.model.getTargetEntityType(),
                            ViewId: this.model.getViewId(),
                            FilteringInput: {
                                Static: true,
                                ControlLinked: false,
                                Value: JSON.stringify(this.model.filtering.getFilter())
                            },
                            DataSetUIOptions: {
                                displayQuickFind: false,
                                displayIndex: false,
                                displayCommandBar: true,
                                displayViewSelector: false,
                            }
                        },
                        EnableGroupBy: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        EnableFiltering: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        EnableEditing: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        ReflowBehavior: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "Reflow",
                            Primary: false
                        }
                    },
                    key: this.gridId,
                    id: this.gridId
                };
            };
            return GridControl;
        }());
        BusinessClosureListControl.GridControl = GridControl;
        var Constants;
        (function (Constants) {
            Constants.GRID_ID = "BusinessClosureGridControlID";
            Constants.CONTAINER_ID = "BusinessClosureGridContainerID";
        })(Constants = BusinessClosureListControl.Constants || (BusinessClosureListControl.Constants = {}));
    })(BusinessClosureListControl = MscrmControls.BusinessClosureListControl || (MscrmControls.BusinessClosureListControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="PrivateReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var BusinessClosureListControl;
    (function (BusinessClosureListControl) {
        'use strict';
        var NavButtonDirection;
        (function (NavButtonDirection) {
            NavButtonDirection[NavButtonDirection["Left"] = 0] = "Left";
            NavButtonDirection[NavButtonDirection["Right"] = 1] = "Right";
        })(NavButtonDirection || (NavButtonDirection = {}));
        var YearPickerControl = (function () {
            function YearPickerControl() {
                this.onYearChanged = function (a, b, c) { };
                this.allocateGUIDs();
            }
            YearPickerControl.prototype.allocateGUIDs = function () {
                this.elementGUIDs = {};
                var elementNames = [
                    Constants.YEAR_NAVIGATION_CONTAINER,
                    YearPickerControl.getNavButtonName(NavButtonDirection.Left),
                    YearPickerControl.getNavButtonIconName(NavButtonDirection.Left),
                    Constants.YEAR_TEXTBOX_CONTAINER,
                    Constants.YEAR_TEXBOX,
                    YearPickerControl.getNavButtonName(NavButtonDirection.Right),
                    YearPickerControl.getNavButtonIconName(NavButtonDirection.Right)
                ];
                for (var name_1 in elementNames) {
                    this.elementGUIDs[name_1] =
                        MscrmCommon.ControlUtils.ControlGuidGenerator
                            .newGuid(name_1);
                }
            };
            YearPickerControl.prototype.setOnYearChanged = function (onYearChanged) {
                this.onYearChanged = onYearChanged;
                return this;
            };
            YearPickerControl.prototype.init = function (context, notifyOutputChanged, state) {
                this.context = context;
                this.model = new Date().getFullYear();
                this.createElement = this.context.factory.createElement;
                YearPickerStyles.initialize(this.context.theming);
            };
            YearPickerControl.prototype.updateView = function (context) {
                this.context = context;
                var res = context.resources;
                var currentTooltip = res.getString(Constants.RESOURCEKEY_CURRENT_YEAR);
                var prevTooltip = res.getString(Constants.RESOURCEKEY_PREVIOUS_YEAR);
                var nextTooltip = res.getString(Constants.RESOURCEKEY_NEXT_YEAR);
                var textInput = this.createYearTextInput(currentTooltip);
                var leftButton = this.createNavButton(NavButtonDirection.Left, this.onLeftNavigationButtonClicked, prevTooltip);
                var rightButton = this.createNavButton(NavButtonDirection.Right, this.onRightNavigationButtonClicked, nextTooltip);
                var containerId = this.elementGUIDs[Constants.YEAR_NAVIGATION_CONTAINER];
                this.view = this.createElement("CONTAINER", {
                    id: containerId,
                    key: containerId,
                    style: YearPickerStyles.navigationContainer
                }, [leftButton, textInput, rightButton]);
                return this.view;
            };
            YearPickerControl.prototype.getOutputs = function () {
                return null;
            };
            YearPickerControl.prototype.destroy = function () {
                this.context = null;
                this.onYearChanged = null;
                this.createElement = null;
                this.view = null;
            };
            YearPickerControl.getNavButtonName = function (direction) {
                return Constants.PREFIX + direction + Constants.NAVIGATION_BUTTON;
            };
            YearPickerControl.prototype.createNavButton = function (direction, onClick, tooltip) {
                var icon = this.createIcon(direction);
                var name = YearPickerControl.getNavButtonName(direction);
                var id = this.elementGUIDs[name];
                return this.createElement("BUTTON", {
                    key: id,
                    id: id,
                    style: YearPickerStyles.navigationButton,
                    onClick: onClick.bind(this),
                    title: tooltip
                }, icon);
            };
            YearPickerControl.getNavButtonIconName = function (direction) {
                return Constants.PREFIX + direction +
                    Constants.NAVIGATION_BUTTON_ICON;
            };
            YearPickerControl.prototype.createIcon = function (direction) {
                var name = YearPickerControl.getNavButtonIconName(direction);
                var type = direction === NavButtonDirection.Left ?
                    Constants.ICON_SYMBOL_TYPE_LEFT_CHEVRON :
                    Constants.ICON_SYMBOL_TYPE_RIGHT_CHEVRON;
                var icon = this.context.factory.createElement("MICROSOFTICON", {
                    id: name,
                    key: name,
                    type: type,
                    accessibilityHidden: true
                });
                return icon;
            };
            YearPickerControl.prototype.createYearTextInput = function (tooltip) {
                var textBoxId = this.elementGUIDs[Constants.YEAR_TEXBOX];
                var yearTextBox = this.context.factory.createElement("TEXTINPUT", {
                    key: textBoxId,
                    id: textBoxId,
                    value: this.model,
                    multiline: false,
                    onBlur: this.onBlurYearTextInput.bind(this),
                    style: YearPickerStyles.yearTextInput,
                    tooltip: tooltip
                });
                var containerId = this.elementGUIDs[Constants.YEAR_TEXTBOX_CONTAINER];
                return this.context.factory.createElement("CONTAINER", {
                    id: containerId,
                    key: containerId
                }, [yearTextBox]);
            };
            YearPickerControl.prototype.onBlurYearTextInput = function (control) {
                var year = control.currentTarget.value;
                if (isNaN(year)) {
                    control.currentTarget.value = this.model;
                }
                else {
                    this.updateYear(Number(year));
                }
            };
            YearPickerControl.prototype.onLeftNavigationButtonClicked = function () {
                this.updateYear(this.model - 1);
            };
            YearPickerControl.prototype.onRightNavigationButtonClicked = function () {
                this.updateYear(this.model + 1);
            };
            YearPickerControl.prototype.updateYear = function (userValue) {
                var userMadeNoChanges = userValue === this.model;
                if (userMadeNoChanges)
                    return;
                var previousModel = this.model;
                var isValidYear = userValue >= Constants.YEAR_MIN
                    && userValue <= Constants.YEAR_MAX;
                if (isValidYear) {
                    var floor = Math.floor(userValue);
                    var userEnteredSameNumber = this.model === floor;
                    if (userEnteredSameNumber) {
                        var userEnteredDecimal = this.model !== userValue;
                        if (userEnteredDecimal) {
                            this.context.utils.requestRender();
                        }
                        return;
                    }
                    this.model = floor;
                }
                this.context.utils.requestRender();
                this.onYearChanged(userValue, previousModel, this.model);
            };
            return YearPickerControl;
        }());
        BusinessClosureListControl.YearPickerControl = YearPickerControl;
        var Constants;
        (function (Constants) {
            // Year Range chosen from:
            // https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/behavior-format-date-time-field
            // https://docs.microsoft.com/en-us/sql/t-sql/data-types/datetime-transact-sql
            Constants.YEAR_MAX = 9999;
            Constants.YEAR_MIN = 1763;
            Constants.PREFIX = "YP_";
            Constants.YEAR_TEXBOX = Constants.PREFIX + "YearTexbox";
            Constants.YEAR_TEXTBOX_CONTAINER = Constants.PREFIX + "YearTextBoxContainer";
            Constants.NAVIGATION_BUTTON_ICON = "NavigationButtonIconContainer";
            Constants.NAVIGATION_BUTTON = "NavigationButtonContainer";
            Constants.YEAR_NAVIGATION_CONTAINER = "YearNavigationContainer";
            Constants.ICON_SYMBOL_TYPE_LEFT_CHEVRON = 299;
            Constants.ICON_SYMBOL_TYPE_RIGHT_CHEVRON = 298;
            Constants.BUTTON_TOOLTIP = "ToolTip";
            Constants.CURRENT_YEAR = Constants.PREFIX + "CurrentYearLabel";
            Constants.CURRENT_YEAR_EDIT = Constants.PREFIX + "CurrentYearEdit";
            Constants.RESOURCEKEY_CURRENT_YEAR = "BCL_TooltipCurrentYear";
            Constants.RESOURCEKEY_PREVIOUS_YEAR = "BCL_TooltipPreviousYear";
            Constants.RESOURCEKEY_NEXT_YEAR = "BCL_TooltipNextYear";
        })(Constants = BusinessClosureListControl.Constants || (BusinessClosureListControl.Constants = {}));
        var YearPickerStyles = (function () {
            function YearPickerStyles() {
            }
            YearPickerStyles.initialize = function (theming) {
            };
            return YearPickerStyles;
        }());
        YearPickerStyles.yearTextInput = {
            width: "3rem",
            height: "1.2rem",
            textAlign: "center",
            border: "none",
            backgroundColor: "lightgray"
        };
        YearPickerStyles.navigationButton = {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            alignSelf: "center",
            border: "none",
            backgroundColor: "transparent",
            cursor: "pointer",
            margin: "0rem"
        };
        YearPickerStyles.navigationContainer = {
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            alignSelf: "center",
            border: "none",
            backgroundColor: "lightgray",
            cursor: "pointer",
            margin: "0rem",
            width: "100%",
            paddingTop: "0.4rem",
            paddingBottom: "0.4rem"
        };
        BusinessClosureListControl.YearPickerStyles = YearPickerStyles;
    })(BusinessClosureListControl = MscrmControls.BusinessClosureListControl || (MscrmControls.BusinessClosureListControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="BusinessClosureListControl.ts" />
/// <reference path="GridControl.ts"/>
/// <reference path="YearPickerControl.ts"/>
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../references/internal/TypeDefinitions/CommonControl/mscrm.d.ts" />
/// <reference path="../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts"/>
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="PrivateReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var BusinessClosureListControl;
    (function (BusinessClosureListControl_1) {
        'use strict';
        // Uses the default view of the business closure's entity to 
        // create a CCF composite control of a year picker and 
        // grid displaying the business closures.  The grid is filtered
        // by the year specified by the user in the year picker control.
        // The grid is initialized by filtering on the current year.
        var BusinessClosureListControl = (function () {
            function BusinessClosureListControl() {
                this.yearPickerControl = new BusinessClosureListControl_1.YearPickerControl()
                    .setOnYearChanged(this.onYearChanged.bind(this));
                this.gridControl = new BusinessClosureListControl_1.GridControl();
                this.containerId = MscrmCommon.ControlUtils.ControlGuidGenerator
                    .newGuid(Constants.TOPMOST_CONTAINERID);
                this.errorMessageShown = false;
            }
            BusinessClosureListControl.prototype.init = function (context, notifyOutputChanged, state) {
                this.context = context;
                BusinessClosureListControlStyles.initialize(this.context.theming);
                this.yearPickerControl.init(this.context, notifyOutputChanged, state);
                this.gridControl.init(this.context, notifyOutputChanged, state);
                this.notifyOutputChanged = notifyOutputChanged || (function () { });
            };
            BusinessClosureListControl.prototype.updateView = function (context) {
                this.view = this.createView(context);
                return this.view;
            };
            BusinessClosureListControl.prototype.getOutputs = function () {
                return null;
            };
            BusinessClosureListControl.prototype.destroy = function () {
                this.context = null;
                this.yearPickerControl.destroy();
                this.yearPickerControl = null;
                this.gridControl.destroy();
                this.gridControl = null;
                this.view = null;
            };
            BusinessClosureListControl.prototype.onYearChanged = function (userValue, previousValue, newValue) {
                var filter = this.createYearFilter(newValue);
                this.gridControl.applyFilter(filter);
            };
            BusinessClosureListControl.prototype.createYearFilter = function (year) {
                var yearCondition = {
                    attributeName: "msdyn_selectedyear",
                    conditionOperator: 0 /* Equal */,
                    value: year.toString()
                };
                var filterExpr = {
                    filterOperator: 0 /* And */,
                    conditions: [yearCondition]
                };
                return filterExpr;
            };
            BusinessClosureListControl.prototype.createView = function (context) {
                var topMostContainer = null;
                try {
                    var yearPickerView = this.yearPickerControl.updateView(context);
                    var gridView = this.gridControl.updateView(context);
                    topMostContainer = this.context.factory.createElement("CONTAINER", {
                        id: this.containerId,
                        key: this.containerId,
                        style: BusinessClosureListControlStyles.topMostContainer,
                    }, [yearPickerView, gridView]);
                }
                catch (e) {
                    this.showAndReportErrorMessage();
                }
                return topMostContainer;
            };
            BusinessClosureListControl.prototype.showAndReportErrorMessage = function () {
                if (this.errorMessageShown) {
                    return;
                }
                var msg = this.context.resources.getString(Constants.RESOURCEKEY_GENERIC_ERROR_OCCURRED);
                var lbl = this.context.resources.getString(Constants.RESOURCEKEY_CONFIRMBUTTONTEXT);
                var alertMessage = {
                    text: msg,
                    confirmButtonLabel: lbl
                };
                this.context.navigation.openAlertDialog(alertMessage);
                this.errorMessageShown = true;
                var error = {
                    name: Constants.BUSINESSCLOSURECONTROL_CREATE_FAILURE,
                    message: msg
                };
                this.context.reporting.reportFailure(Constants.BUSINESSCLOSURECONTROL_NAME, error);
            };
            return BusinessClosureListControl;
        }());
        BusinessClosureListControl_1.BusinessClosureListControl = BusinessClosureListControl;
        var Constants;
        (function (Constants) {
            Constants.BUSINESSCLOSURECONTROL_NAME = "BusinessClosureListControl";
            Constants.TOPMOST_CONTAINERID = "BusinessClosureGrid_TopMostContainer";
            Constants.RESOURCEKEY_CONFIRMBUTTONTEXT = "BCL_ConfirmButtonText";
            Constants.RESOURCEKEY_GENERIC_ERROR_OCCURRED = "BCL_Error_GenericErrorOccurred";
            Constants.BUSINESSCLOSURECONTROL_CREATE_FAILURE = "BusinessClosureControlCreateFailure";
        })(Constants = BusinessClosureListControl_1.Constants || (BusinessClosureListControl_1.Constants = {}));
        var BusinessClosureListControlStyles = (function () {
            function BusinessClosureListControlStyles() {
            }
            BusinessClosureListControlStyles.initialize = function (theming) {
                BusinessClosureListControlStyles.topMostContainer["margin"]
                    = theming.measures.measure075;
            };
            return BusinessClosureListControlStyles;
        }());
        BusinessClosureListControlStyles.topMostContainer = {
            display: "flex",
            flexDirection: "column",
            width: "100%",
            flex: "1",
            maxWidth: "100%",
            overflow: "hidden"
        };
        BusinessClosureListControl_1.BusinessClosureListControlStyles = BusinessClosureListControlStyles;
    })(BusinessClosureListControl = MscrmControls.BusinessClosureListControl || (MscrmControls.BusinessClosureListControl = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=BusinessClosureListControl.js.map