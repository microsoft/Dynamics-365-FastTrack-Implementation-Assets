﻿IF EXISTS (SELECT * FROM sys.procedures WHERE NAME = 'p_msdyn_URS_690_PotassiumToCalcium_GenericServiceCenterToFacility')
BEGIN
    DROP PROCEDURE [dbo].p_msdyn_URS_690_PotassiumToCalcium_GenericServiceCenterToFacility
END
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].p_msdyn_URS_690_PotassiumToCalcium_GenericServiceCenterToFacility
    @BatchSize INT,
    @BatchStart INT
AS
BEGIN
	-- Convert Generic resource of type ServiceCenter to Facility resource
	-- There is no corresponding C# code.

	LINENO 0;
    SAVE TRANSACTION SavePoint
	SET NOCOUNT ON
    BEGIN TRY
		UPDATE TOP (@BatchSize) BookableResourceBase
		SET ResourceType = '7', msdyn_GenericType = null
		WHERE ResourceType = '1'
		AND msdyn_GenericType = '690970000'
		SELECT 'success:' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ':'
            + 'updated ' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ' BookableResource'
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION SavePoint;
		SELECT 'error:' + CONVERT(VARCHAR(MAX), ERROR_PROCEDURE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_NUMBER())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_LINE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_MESSAGE())
    END CATCH
END
