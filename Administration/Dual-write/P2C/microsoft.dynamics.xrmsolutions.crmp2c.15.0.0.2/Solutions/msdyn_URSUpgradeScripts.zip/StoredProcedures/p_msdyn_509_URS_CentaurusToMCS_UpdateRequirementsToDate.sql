﻿IF EXISTS (SELECT * FROM sys.procedures WHERE NAME = 'p_msdyn_URS_509_CentaurusToMCS_UpdateRequirementsToDate')
BEGIN
    DROP PROCEDURE [dbo].p_msdyn_URS_509_CentaurusToMCS_UpdateRequirementsToDate
END
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].p_msdyn_URS_509_CentaurusToMCS_UpdateRequirementsToDate
    @BatchSize INT,
    @BatchStart INT
AS
BEGIN
    LINENO 0;
    -- Based on 
    -- URS action URSUpgradeJobID.p_msdyn_URS_509_CentaurusToMCS_UpdateRequirementsToDate (509)
    --     509 = UpgradeScripts_CentaurusToMCS_UpdateRequirementsToDate
    -- File: /Solutions/MicrosoftDynamicsScheduling/Fps/Fps/Actions/FpsActionJobs/URSUpgradeJobs.cs
    -- Method: UpdateRequirementsToDateField()
    --
    --        var requirementsToBeUpdated = DataContext.msdyn_resourcerequirementSet
    --            .Where(r => r.msdyn_todate != null)
    --            .Select(r => new { r.msdyn_resourcerequirementId, r.msdyn_todate }).ToList();
    --
    --        foreach (var requirement in requirementsToBeUpdated)
    --        {
    --            // If minute value ends in :59, :29 we then assume value was already updated
    --            if (requirement.msdyn_todate.Value.Minute == 29 || requirement.msdyn_todate.Value.Minute == 59) continue;
    --
    --            OrganizationService.Update(new msdyn_resourcerequirement
    --            {
    --                Id = requirement.msdyn_resourcerequirementId.Value,
    --                msdyn_todate = requirement.msdyn_todate.Value.AddDays(1).AddMinutes(-1)
    --            });
    --            recordsUpdated++;
    --        }

    SAVE TRANSACTION SavePoint
    SET NOCOUNT ON
    
    BEGIN TRY
        -- For processing in batches, UPDATE TOP(N) works correctly,
        -- because the WHERE clause excludes rows we've already processed.
        -- We can guarantee that if we have updated a row, then it will
        -- not be updated again.
        UPDATE TOP(@BatchSize) msdyn_resourcerequirementBase
        SET msdyn_todate = DATEADD(day, 1, DATEADD(minute, -1, msdyn_todate))
        WHERE msdyn_todate IS NOT null
        AND DATEPART(minute, msdyn_todate) != 29
        AND DATEPART(minute, msdyn_todate) != 59

        SELECT 'success:' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ':'
            + 'updated ' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ' msdyn_resourcerequirement'
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION SavePoint;
		SELECT 'error:' + CONVERT(VARCHAR(MAX), ERROR_PROCEDURE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_NUMBER())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_LINE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_MESSAGE())
    END CATCH
END