function setName() {
    var resourceField = Xrm.Page.getAttribute("resourcetype");
    var optionSetValue = resourceField.getValue();
    if (optionSetValue != null) {
        // If the resource type is Equipment (optionSetValue == 4) or Facility (optionSetValue == 7) 
        if (optionSetValue == 4 || optionSetValue == 7) {
            var facilityField = Xrm.Page.getAttribute("msdyn_facilityequipmentid").getValue();
            if (facilityField != null) {
                Xrm.Page.getAttribute("name").setValue(facilityField[0].name);
            }
        }
    }
}
