/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./CommerceCustomerServiceAddIn/index.ts":
/*!***********************************************!*\
  !*** ./CommerceCustomerServiceAddIn/index.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.CommerceCustomerServiceAddIn = void 0;\n\nvar CommerceCustomerServiceAddIn =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function CommerceCustomerServiceAddIn() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  CommerceCustomerServiceAddIn.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    // Add control initialization code\n    this.iframe = document.createElement('iframe'); // TODO: what sandbox attributes should be set\n\n    this.updateSrc(context);\n    container.style.width = '100%';\n    container.style.height = '100%';\n    this.iframe.style.width = '100%';\n    this.iframe.style.height = '100%';\n    container.appendChild(this.iframe);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  CommerceCustomerServiceAddIn.prototype.updateView = function (context) {\n    // Add code to update control view\n    this.updateSrc(context);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  CommerceCustomerServiceAddIn.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  CommerceCustomerServiceAddIn.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  CommerceCustomerServiceAddIn.prototype.updateSrc = function (context) {\n    var _a, _b, _c, _d, _e;\n\n    if (context && context.parameters) {\n      var iframeSrc = void 0;\n      var customerId = void 0;\n\n      if ((_a = context.parameters.urlEndpoint) === null || _a === void 0 ? void 0 : _a.raw) {\n        iframeSrc = context.parameters.urlEndpoint.raw;\n      } else {\n        iframeSrc = '';\n      }\n\n      if (iframeSrc && !iframeSrc.endsWith('/')) {\n        iframeSrc += '/';\n      }\n\n      if (iframeSrc) {\n        iframeSrc += \"?embedded=\".concat(context.parameters.Embedded.raw);\n\n        if (window.location) {\n          iframeSrc += \"&embedOrigin=\".concat(window.location.protocol, \"//\").concat(window.location.hostname);\n        }\n\n        if ((_b = context.parameters.menuItem) === null || _b === void 0 ? void 0 : _b.raw) {\n          iframeSrc += \"&mi=\".concat(context.parameters.menuItem.raw);\n        }\n\n        if ((_c = context.parameters.company) === null || _c === void 0 ? void 0 : _c.raw) {\n          iframeSrc += \"&cmp=\".concat(context.parameters.company.raw);\n        }\n\n        if ((_d = context.parameters.customerId) === null || _d === void 0 ? void 0 : _d.raw) {\n          iframeSrc += \"&customerId=\".concat(context.parameters.customerId.raw);\n        }\n\n        if ((_e = context.userSettings) === null || _e === void 0 ? void 0 : _e.isRTL) {\n          iframeSrc += '&useRTL=true';\n        }\n\n        if (iframeSrc !== this.iframe.src) {\n          this.iframe.src = iframeSrc;\n        }\n      }\n    }\n  };\n\n  return CommerceCustomerServiceAddIn;\n}();\n\nexports.CommerceCustomerServiceAddIn = CommerceCustomerServiceAddIn;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CommerceCustomerServiceAddIn/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./CommerceCustomerServiceAddIn/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Commerce.CustomerService.CommerceCustomerServiceAddIn', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CommerceCustomerServiceAddIn);
} else {
	var Commerce = Commerce || {};
	Commerce.CustomerService = Commerce.CustomerService || {};
	Commerce.CustomerService.CommerceCustomerServiceAddIn = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CommerceCustomerServiceAddIn;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}