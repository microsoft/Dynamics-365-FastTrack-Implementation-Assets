using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.CommonDataModel.ObjectModel.Cdm;
using Microsoft.CommonDataModel.ObjectModel.Enums;
using Microsoft.CommonDataModel.ObjectModel.Storage;
using System.Collections.Generic;
using System.Linq;

namespace CDMUtil
{

    public static class CDMManifestUtil
    {

        private const string FoundationJsonPath = "cdm:/foundations.cdm.json";

        [FunctionName("getManifestDefinition")]
        public static async Task<IActionResult> run(
          [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
          ILogger log, ExecutionContext context)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            //get data from 
            string tableList = req.Headers["TableList"];

            var path = System.IO.Path.Combine(context.FunctionDirectory, "..\\Artifacts.json");
            using (StreamReader r = new StreamReader(path))
            {
                string artifactsStr = await r.ReadToEndAsync();
                var artifacts = JsonConvert.DeserializeObject<List<Artifacts>>(artifactsStr);
                string[] tables = tableList.Split(',');
                List<ManifestDefinition> ManifestDefinitions = new List<ManifestDefinition>();
                
                foreach (string table in tables)
                {
                    string tableName, key, value, manifestName, manifestLocation;

                    tableName = table.Trim();
                    key = "Tables:" + tableName;
                                       
                    var artifact = artifacts.Find(x => x.Key.Equals(key));
                    
                    if (artifact != null)
                    {
                        value = artifact.Value;
                    }
                    else
                    {
                        value = "Tables/Custom/" + tableName;
                    }
                    manifestLocation = value.Replace("/" + tableName, "");
                    manifestName = manifestLocation.Substring(manifestLocation.LastIndexOf('/')+1);

                    ManifestDefinition md = new ManifestDefinition();
                    md.TableName        = tableName;
                    md.DataLocation     = value;
                    md.ManifestLocation = manifestLocation;
                    md.ManifestName = manifestName;

                    ManifestDefinitions.Add(md);
                }
                var grouped = ManifestDefinitions.GroupBy(c => new { c.ManifestLocation, c.ManifestName })
                                                 .Select(g => new
                                                 {
                                                     ManifestLocation = g.Key.ManifestLocation,
                                                     ManifestName = g.Key.ManifestName,
                                                     Tables = g.Select(table => new {table.TableName})
                                                 }); 

                ManifestDefinitions mds = new ManifestDefinitions();
                mds.Tables = ManifestDefinitions;
                mds.Manifests = grouped;
                return new OkObjectResult(JsonConvert.SerializeObject(mds));
            }
        }
        [FunctionName("createManifest")]
        public static async Task<IActionResult> excecute(
           [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
           ILogger log, ExecutionContext context)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            //get data from 
            string hostName = req.Headers["HostName"];
            string cdmFolder = req.Headers["CDMFolder"];
            string localFolder = req.Headers["LocalFolder"];
            string createCorpus = req.Headers["CreateCorpus"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            EntityList entityList = JsonConvert.DeserializeObject<EntityList>(requestBody);

            var cdmCorpus = mountStorage(context, hostName, cdmFolder, localFolder);

            string responseMessage;
            if (createCorpus.Equals("true"))
            {
                responseMessage = await createManifest(cdmCorpus, entityList, true);
            }
            else
            {
                responseMessage = await createManifest(cdmCorpus, entityList, false);
            }

            return new OkObjectResult(responseMessage);
        }



        private static CdmCorpusDefinition mountStorage(ExecutionContext context, string hostName, string cdmFolder, string localFolder)
        {
            var TenantId = System.Environment.GetEnvironmentVariable("TenantId");
            var AppId = System.Environment.GetEnvironmentVariable("AppId"); ;
            var AppSecret = System.Environment.GetEnvironmentVariable("AppSecret");

            // Make a corpus, the corpus is the collection of all documents and folders created or discovered while navigating objects and paths
            var cdmCorpus = new CdmCorpusDefinition();

            Console.WriteLine("configure storage adapters");
            string firstChar;

            firstChar = cdmFolder.Substring(0, 1);
            if (firstChar != "/")
            {
                cdmFolder = "/" + cdmFolder;
            }

            firstChar = localFolder.Substring(0, 1);
            if (firstChar != "/")
            {
                localFolder = "/" + localFolder;
            }

            if (cdmFolder.EndsWith("/"))
            {
                cdmFolder = cdmFolder.Remove(cdmFolder.Length - 1, 1);
            }
            if (localFolder.EndsWith("/"))
            {
                localFolder = localFolder.Remove(localFolder.Length - 1, 1);
            }

            cdmCorpus.Storage.Mount("cdm", new ADLSAdapter(
            hostName, // Hostname.
            cdmFolder, // Root.
            TenantId,  // Tenant ID.
            AppId,  // Client ID.
            AppSecret // Client secret.
            ));



            cdmCorpus.Storage.Mount("local", new ADLSAdapter(
            hostName, // Hostname.
            cdmFolder + localFolder, // Root.
            TenantId,  // Tenant ID.
            AppId,  // Client ID.
            AppSecret // Client secret.
          ));

            cdmCorpus.Storage.DefaultNamespace = "local"; // local is our default. so any paths that start out navigating without a device tag will assume local

            return cdmCorpus;
        }
        static async Task<String> createManifest(CdmCorpusDefinition cdmCorpus, EntityList entityList, Boolean createCorpus)
        {
            bool manifestCreated = true;
            string response = "";
            try
            {
                string manifestName = entityList.manifestName;

                Console.WriteLine("Make placeholder manifest");
                // Add the temp manifest to the root of the local adapter in the corpus
                var localRoot = cdmCorpus.Storage.FetchRootFolder("local");

                CdmManifestDefinition manifestAbstract = cdmCorpus.MakeObject<CdmManifestDefinition>(CdmObjectType.ManifestDef, "tempAbstract");
                localRoot.Documents.Add(manifestAbstract, "TempAbstract.manifest.cdm.json");
                // manifestAbstract = await cdmCorpus.FetchObjectAsync<CdmManifestDefinition>(localRoot.AtCorpusPath + manifestName+ ".manifest.cdm.json");
                //if (manifestAbstract == null)
                // {
                // Make the temp manifest and add it to the root of the local documents in the corpus
                //  manifestAbstract = cdmCorpus.MakeObject<CdmManifestDefinition>(CdmObjectType.ManifestDef, "tempAbstract");
                //  localRoot.Documents.Add(manifestAbstract, "TempAbstract.manifest.cdm.json");
                //  }

                // Create two entities from scratch, and add some attributes, traits, properties, and relationships in between
                Console.WriteLine("Create net new entities");

                List<EntityDefinition> EntityDefinitions = entityList.entityDefinitions;

                foreach (EntityDefinition entityDefinition in EntityDefinitions)
                {
                    string entityName = entityDefinition.name;
                    string entityDesciption = entityDefinition.description;
                    // Create the entity definition instance
                    var entity = cdmCorpus.MakeObject<CdmEntityDefinition>(CdmObjectType.EntityDef, entityName, false);
                    // Add properties to the entity instance
                    entity.DisplayName = entityName;
                    entity.Version = "1.0.0";
                    entity.Description = entityDesciption;

                    if (createCorpus == false)
                    {
                        // Add each declaration
                        manifestAbstract.Entities.Add(entityDefinition.name, "cdm:" + entityDefinition.corpusPath);

                    }
                    else
                    {
                        List<Attribute> attributes = entityDefinition.attributes;

                        foreach (Attribute a in attributes)
                        {
                            // Add type attributes to the entity instance
                            var attribute = CreateEntityAttributeWithPurposeAndDataType(cdmCorpus, a.name, "hasA", a.dataType);
                            entity.Attributes.Add(attribute);
                        }

                        // Create the document which contains the entity
                        var entityDoc = cdmCorpus.MakeObject<CdmDocumentDefinition>(CdmObjectType.DocumentDef, $"{entityName}.cdm.json", false);
                        // Add an import to the foundations doc so the traits about partitons will resolve nicely
                        entityDoc.Imports.Add(FoundationJsonPath);
                        entityDoc.Definitions.Add(entity);
                        // Add the document to the root of the local documents in the corpus
                        localRoot.Documents.Add(entityDoc, entityDoc.Name);
                        manifestAbstract.Entities.Add(entity);
                    }
                }

                var manifestResolved = await manifestAbstract.CreateResolvedManifestAsync(manifestName, null);
                // Add an import to the foundations doc so the traits about partitons will resolve nicely
                manifestResolved.Imports.Add(FoundationJsonPath);

                foreach (CdmEntityDeclarationDefinition eDef in manifestResolved.Entities)
                {
                    // Get the entity being pointed at
                    var localEDef = eDef;
                    var entDef = await cdmCorpus.FetchObjectAsync<CdmEntityDefinition>(localEDef.EntityPath, manifestResolved);
                    var entityDefinition = EntityDefinitions.Find(x => x.name.Contains(entDef.EntityName));
                                       
                    if (entityDefinition != null)
                    {
                        
                        var part = cdmCorpus.MakeObject<CdmDataPartitionDefinition>(CdmObjectType.DataPartitionDef, $"{entDef.EntityName}-data");
                        eDef.DataPartitions.Add(part);
                        part.Explanation = "data files";

                        // We have existing partition files for the custom entities, so we need to make the partition point to the file location
                        part.Location = $"local:{entityDefinition.dataPartitionLocation}/{entityDefinition.partitionPattern}";

                        if (entityDefinition.partitionPattern.Contains("parquet"))
                        {
                            part.ExhibitsTraits.Add("is.partition.format.parquet", false);
                        }
                        //default is csv
                        else
                        {
                            // Add trait to partition for csv params
                            var csvTrait = part.ExhibitsTraits.Add("is.partition.format.CSV", false);
                            csvTrait.Arguments.Add("columnHeaders", "false");
                            csvTrait.Arguments.Add("delimiter", ",");
                        }
                    }
                }
                Console.WriteLine("Save the documents");
                // We can save the documents as manifest.cdm.json format or model.json
                // Save as manifest.cdm.json
                manifestCreated = await manifestResolved.SaveAsAsync($"{manifestName}.manifest.cdm.json", true);
                // Save as a model.json
                // await manifestResolved.SaveAsAsync("model.json", true);
            }
            catch (Exception e)
            {
                response = $"{{\"Response\":\"{ e.InnerException.Message}\"\"}}";
            }

            if (manifestCreated)
            {
                response = "{\"Response\":\"Success\"}";
            }
            else
            {
                response = "{\"Response\":\"Failed\"}";
            }
            return response;
          
        }

        /// <summary>
        /// Create an type attribute definition instance with provided data type.
        /// </summary>
        /// <param name="cdmCorpus"> The CDM corpus. </param>
        /// <param name="attributeName"> The directives to use while getting the resolved entities. </param>
        /// <param name="purpose"> The manifest to be resolved. </param>
        /// <param name="dataType"> The data type.</param>
        /// <returns> The instance of type attribute definition. </returns>
        private static CdmTypeAttributeDefinition CreateEntityAttributeWithPurposeAndDataType(CdmCorpusDefinition cdmCorpus, string attributeName, string purpose, string dataType)
        {
            var entityAttribute = CreateEntityAttributeWithPurpose(cdmCorpus, attributeName, purpose);
            entityAttribute.DataType = cdmCorpus.MakeRef<CdmDataTypeReference>(CdmObjectType.DataTypeRef, dataType, true);
            return entityAttribute;
        }

        /// <summary>
        /// Create an type attribute definition instance with provided purpose.
        /// </summary>
        /// <param name="cdmCorpus"> The CDM corpus. </param>
        /// <param name="attributeName"> The directives to use while getting the resolved entities. </param>
        /// <param name="purpose"> The manifest to be resolved. </param>
        /// <returns> The instance of type attribute definition. </returns>
        private static CdmTypeAttributeDefinition CreateEntityAttributeWithPurpose(CdmCorpusDefinition cdmCorpus, string attributeName, string purpose)
        {
            var entityAttribute = cdmCorpus.MakeObject<CdmTypeAttributeDefinition>(CdmObjectType.TypeAttributeDef, attributeName, false);
            entityAttribute.Purpose = cdmCorpus.MakeRef<CdmPurposeReference>(CdmObjectType.PurposeRef, purpose, true);
            return entityAttribute;
        }

        /// <summary>
        /// Create a relationship linking by creating an eneity attribute definition instance with a trait. 
        /// This allows you to add a resolution guidance to customize your data.
        /// </summary>
        /// <param name="cdmCorpus"> The CDM corpus. </param>
        /// <param name="associatedEntityName"> The name of the associated entity. </param>
        /// <param name="foreignKeyName"> The name of the foreign key. </param>
        /// <param name="attributeExplanation"> The explanation of the attribute.</param>
        /// <returns> The instatnce of entity attribute definition. </returns>
        private static CdmEntityAttributeDefinition CreateAttributeForRelationshipBetweenTwoEntities(
            CdmCorpusDefinition cdmCorpus,
            string associatedEntityName,
            string foreignKeyName,
            string attributeExplanation)
        {
            // Define a relationship by creating an entity attribute
            var entityAttributeDef = cdmCorpus.MakeObject<CdmEntityAttributeDefinition>(CdmObjectType.EntityAttributeDef, foreignKeyName);
            entityAttributeDef.Explanation = attributeExplanation;
            // Creating an entity reference for the associated entity 
            CdmEntityReference associatedEntityRef = cdmCorpus.MakeRef<CdmEntityReference>(CdmObjectType.EntityRef, associatedEntityName, false);

            // Creating a "is.identifiedBy" trait for entity reference
            CdmTraitReference traitReference = cdmCorpus.MakeObject<CdmTraitReference>(CdmObjectType.TraitRef, "is.identifiedBy", false);
            traitReference.Arguments.Add(null, $"{associatedEntityName}/(resolvedAttributes)/{associatedEntityName}Id");

            // Add the trait to the attribute's entity reference
            associatedEntityRef.AppliedTraits.Add(traitReference);
            entityAttributeDef.Entity = associatedEntityRef;

            // Add resolution guidance
            var attributeResolution = cdmCorpus.MakeObject<CdmAttributeResolutionGuidance>(CdmObjectType.AttributeResolutionGuidanceDef);
            attributeResolution.entityByReference = attributeResolution.makeEntityByReference();
            attributeResolution.entityByReference.allowReference = true;
            attributeResolution.renameFormat = "{m}";
            var entityAttribute = CreateEntityAttributeWithPurposeAndDataType(cdmCorpus, $"{foreignKeyName}Id", "identifiedBy", "entityId");
            attributeResolution.entityByReference.foreignKeyAttribute = entityAttribute as CdmTypeAttributeDefinition;
            entityAttributeDef.ResolutionGuidance = attributeResolution;

            return entityAttributeDef;
        }
    }


    public class EntityList
    {
        public string manifestName { get; set; } // this will store the JSON string
        public List<EntityDefinition> entityDefinitions { get; set; } // this will be the actually list. 
    }
    public class EntityDefinition
    {
        public string name { get; set; } // this will store the JSON string
        public string description { get; set; } // this will store the JSON string
        public string corpusPath { get; set; } // this will store the JSON string
        public string dataPartitionLocation { get; set; } // this will store the JSON string
        public string partitionPattern { get; set; } // this will store the JSON string
        public List<Attribute> attributes { get; set; } // this will be the actually list. 
    }

    public class Attribute
    {
        public string name { get; set; }
        public string description { get; set; }
        public Boolean isNullable { get; set; }
        public string dataType { get; set; }


    }
      
    public class Artifacts
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
    public class ManifestDefinition
    {
        public string TableName { get; set; }
        public string DataLocation { get; set; }
        public string ManifestName { get; set; }
        public string ManifestLocation { get; set; }
    }
    public class ManifestDefinitions
    {
        public List<ManifestDefinition> Tables;
        public Object Manifests;
    }

}
