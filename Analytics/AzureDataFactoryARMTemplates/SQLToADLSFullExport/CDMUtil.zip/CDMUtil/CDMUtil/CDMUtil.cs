using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using CDMUtil.Context.ADLS;
using CDMUtil.Context.ObjectDefinitions;
using CDMUtil.Manifest;
using CDMUtil.SQL;

namespace CDMUtil
{
    public static class CDMUtil
    {
        [FunctionName("getManifestDefinition")]
        public static async Task<IActionResult> getManifestDefinition(
          [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
          ILogger log, ExecutionContext context)
        {
            log.LogInformation("getManifestDefinition request started");
            
            string tableList = req.Headers["TableList"];
            
            var path = System.IO.Path.Combine(context.FunctionDirectory, "..\\Manifest\\Artifacts.json");

            var mds = await ManifestHandler.getManifestDefinition(path, tableList);

            return new OkObjectResult(JsonConvert.SerializeObject(mds));
            
        }
        [FunctionName("manifestToSynapseView")]
        public static async Task<IActionResult> manifestToSynapseView(
          [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
          ILogger log, ExecutionContext context)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            //get data from 
            string storageAccount = req.Headers["StorageAccount"];
            string rootFolder = req.Headers["RootFolder"];
            string localFolder = req.Headers["ManifestLocation"];
            string manifestName = req.Headers["ManifestName"];

            var TenantId = System.Environment.GetEnvironmentVariable("TenantId");
            var AppId = System.Environment.GetEnvironmentVariable("AppId"); ;
            var AppSecret = System.Environment.GetEnvironmentVariable("AppSecret");
            
            AdlsContext adlsContext = new AdlsContext(){ 
                                                            StorageAccount = storageAccount, 
                                                            FileSytemName = rootFolder, 
                                                            TenantId = TenantId, 
                                                            ClientAppId = AppId, 
                                                            ClientSecret = AppSecret 
                                                        };

            // var manifestHandler = new ManifestHandler(adlsContext, localFolder);

            SQLStatements statements = new SQLStatements();
            List<SQLStatement> statementsList = new List<SQLStatement>();

            await ManifestHandler.manifestToSQL(adlsContext, manifestName, localFolder, statementsList);
            statements.Statements = statementsList;

            var SQLHandler =  new SQLHandler(System.Environment.GetEnvironmentVariable("SQL-On-Demand"));
            SQLHandler.executeStatements(statements);

            return new OkObjectResult(JsonConvert.SerializeObject(statements));
        }

        [FunctionName("createManifest")]
        public static async Task<IActionResult> excecute(
           [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
           ILogger log, ExecutionContext context)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            //get data from 
            string storageAccount = req.Headers["StorageAccount"];
            string rootFolder = req.Headers["RootFolder"];
            string localFolder = req.Headers["LocalFolder"];
 

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            EntityList entityList = JsonConvert.DeserializeObject<EntityList>(requestBody);

            var TenantId = System.Environment.GetEnvironmentVariable("TenantId");
            var AppId = System.Environment.GetEnvironmentVariable("AppId"); ;
            var AppSecret = System.Environment.GetEnvironmentVariable("AppSecret");
            AdlsContext adlsContext = new AdlsContext() 
                                                        { 
                                                            StorageAccount = storageAccount, 
                                                            FileSytemName = rootFolder, 
                                                            TenantId=TenantId, 
                                                            ClientAppId= AppId, 
                                                            ClientSecret=AppSecret
                                                        };
            ManifestHandler manifestHandler = new ManifestHandler(adlsContext, localFolder);
            
            bool ManifestCreated = await manifestHandler.createManifest(entityList);

            //Folder structure Tables/AccountReceivable/Group
            var subFolders = localFolder.Split('/');
            string localFolderPath = "";
            
            for (int i = 0; i < subFolders.Length - 1; i++)
            {
                var currentFolder = subFolders[i];
                var nextFolder = subFolders[i + 1];
                localFolderPath = $"{localFolderPath}/{currentFolder}";

                ManifestHandler SubManifestHandler = new ManifestHandler(adlsContext, localFolderPath);
                await SubManifestHandler.createSubManifest(currentFolder, nextFolder);
            }

            var status = new ManifestStatus() { ManifestName = entityList.manifestName, IsManifestCreated = ManifestCreated };
            
            return new OkObjectResult(JsonConvert.SerializeObject(status));
        }

    }
}
