﻿using CDMUtil.Context.ObjectDefinitions;
using System.Data.SqlClient;

namespace CDMUtil.SQL
{
    class SQLHandler
    {
        private string SQLConnectionStr;

        public SQLHandler(string SqlConnectionStr)
        {
            this.SQLConnectionStr = SqlConnectionStr;
        }
        public  void executeStatements(SQLStatements sqlStatements)
        {
            SqlConnection conn = new SqlConnection(SQLConnectionStr);
            conn.Open();

            foreach (var s in sqlStatements.Statements)
            {
                using (var command = new SqlCommand(s.Statement, conn))
                {
                    try
                    {
                        command.ExecuteNonQuery();
                        s.Created = true;
                    }
                    catch (SqlException ex)
                    {
                        s.Created = false;
                    }
                }
            }

            conn.Close();
        }
    }
}
