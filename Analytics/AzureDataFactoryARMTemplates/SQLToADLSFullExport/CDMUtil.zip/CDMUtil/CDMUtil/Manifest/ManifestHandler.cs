﻿using System;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.CommonDataModel.ObjectModel.Cdm;
using Microsoft.CommonDataModel.ObjectModel.Enums;
using Microsoft.CommonDataModel.ObjectModel.Storage;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using CDMUtil.Context.ADLS;
using CDMUtil.Context.ObjectDefinitions;
using System.Runtime.CompilerServices;

namespace CDMUtil.Manifest
{
    public class ManifestHandler
    {
        public CdmCorpusDefinition cdmCorpus;
        private const string FoundationJsonPath = "cdm:/foundations.cdm.json";
        public ManifestHandler(AdlsContext adlsContext, string currentFolder)
        {
            cdmCorpus = new CdmCorpusDefinition();
            this.mountStorage(adlsContext, currentFolder);
        }
        public async Task<bool> createSubManifest(string manifestName, string nextFolder)
        {
            var localRoot = cdmCorpus.Storage.FetchRootFolder("local");
            bool created = false;

            CdmManifestDefinition manifest = await cdmCorpus.FetchObjectAsync<CdmManifestDefinition>(manifestName + ".manifest.cdm.json");

            if (manifest == null)
            {
                manifest = cdmCorpus.MakeObject<CdmManifestDefinition>(CdmObjectType.ManifestDef, manifestName);
                localRoot.Documents.Add(manifest, manifestName + ".manifest.cdm.json");
            }

            var subManifest = cdmCorpus.MakeObject<CdmManifestDeclarationDefinition>(CdmObjectType.ManifestDeclarationDef, nextFolder, simpleNameRef: false);
            subManifest.ManifestName = nextFolder;
            subManifest.Definition = $"{nextFolder}/{nextFolder}.manifest.cdm.json";

            //check if the submanifest already exists then return
            foreach (var sm in manifest.SubManifests)
            {
                if (sm.ManifestName == subManifest.ManifestName)
                {
                    return false;
                }
            }

            manifest.SubManifests.Add(subManifest);
            created = await manifest.SaveAsAsync($"{manifestName}.manifest.cdm.json");

            return created;
        }
        private void mountStorage(AdlsContext adlsContext, string localFolder)
        {
                       
            string firstChar;

            string rootFolder = adlsContext.FileSytemName;

            firstChar = rootFolder.Substring(0, 1);
            if (firstChar != "/")
            {
                rootFolder = "/" + rootFolder;
            }

            firstChar = localFolder.Substring(0, 1);
            if (firstChar != "/")
            {
                localFolder = "/" + localFolder;
            }

            if (rootFolder.EndsWith("/"))
            {
                rootFolder = rootFolder.Remove(rootFolder.Length - 1, 1);
            }
            if (localFolder.EndsWith("/"))
            {
                localFolder = localFolder.Remove(localFolder.Length - 1, 1);
            }

            cdmCorpus.Storage.Mount("local", new ADLSAdapter(
            adlsContext.StorageAccount, // Hostname.
            rootFolder + localFolder, // Root.
            adlsContext.TenantId,  // Tenant ID.
            adlsContext.ClientAppId,  // Client ID.
            adlsContext.ClientSecret // Client secret.
          ));

          cdmCorpus.Storage.DefaultNamespace = "local"; // local is our default. so any paths that start out navigating without a device tag will assume local
        }

        public async Task<bool> createManifest(EntityList entityList)
        {
            bool manifestCreated = false;          
            string manifestName = entityList.manifestName;

            Console.WriteLine("Make placeholder manifest");
            // Add the temp manifest to the root of the local adapter in the corpus
            var localRoot = cdmCorpus.Storage.FetchRootFolder("local");

            CdmManifestDefinition manifestAbstract = cdmCorpus.MakeObject<CdmManifestDefinition>(CdmObjectType.ManifestDef, "tempAbstract");
            localRoot.Documents.Add(manifestAbstract, "TempAbstract.manifest.cdm.json");

            // Create two entities from scratch, and add some attributes, traits, properties, and relationships in between
            Console.WriteLine("Create net new entities");

            List<EntityDefinition> EntityDefinitions = entityList.entityDefinitions;

            foreach (EntityDefinition entityDefinition in EntityDefinitions)
            {
                string entityName = entityDefinition.name;
                string entityDesciption = entityDefinition.description;
                // Create the entity definition instance
                var entity = cdmCorpus.MakeObject<CdmEntityDefinition>(CdmObjectType.EntityDef, entityName, false);
                // Add properties to the entity instance
                entity.DisplayName = entityName;
                entity.Version = "1.0.0";
                entity.Description = entityDesciption;

                List<ColumnAttribute> attributes = entityDefinition.attributes;

                foreach (ColumnAttribute a in attributes)
                {
                    // Add type attributes to the entity instance
                    var attribute = CreateEntityAttributeWithPurposeAndDataType(cdmCorpus, a.name, "hasA", a.dataType);

                    if (a.dataType.Equals("string", StringComparison.OrdinalIgnoreCase))
                    {
                        attribute.MaximumLength = a.maximumLenght;
                    }
                    entity.Attributes.Add(attribute);
                }

                // Create the document which contains the entity
                var entityDoc = cdmCorpus.MakeObject<CdmDocumentDefinition>(CdmObjectType.DocumentDef, $"{entityName}.cdm.json", false);
                // Add an import to the foundations doc so the traits about partitons will resolve nicely
                entityDoc.Imports.Add(FoundationJsonPath);
                entityDoc.Definitions.Add(entity);
                // Add the document to the root of the local documents in the corpus
                localRoot.Documents.Add(entityDoc, entityDoc.Name);
                manifestAbstract.Entities.Add(entity);
            }

            CdmManifestDefinition manifestResolved = await manifestAbstract.CreateResolvedManifestAsync(manifestName, null);

            // Add an import to the foundations doc so the traits about partitons will resolve nicely
            manifestResolved.Imports.Add(FoundationJsonPath);

            foreach (CdmEntityDeclarationDefinition eDef in manifestResolved.Entities)
            {
                // Get the entity being pointed at
                var localEDef = eDef;
                var entDef = await cdmCorpus.FetchObjectAsync<CdmEntityDefinition>(localEDef.EntityPath, manifestResolved);
                var entityDefinition = EntityDefinitions.Find(x => x.name.Equals(entDef.EntityName, StringComparison.OrdinalIgnoreCase));

                if (entityDefinition != null)
                {

                    var part = cdmCorpus.MakeObject<CdmDataPartitionDefinition>(CdmObjectType.DataPartitionDef, $"{entDef.EntityName}-data");
                    eDef.DataPartitions.Add(part);
                    part.Explanation = "data files";

                    // We have existing partition files for the custom entities, so we need to make the partition point to the file location
                    part.Location = $"local:{entityDefinition.dataPartitionLocation}/{entityDefinition.partitionPattern}";

                    if (entityDefinition.partitionPattern.Contains("parquet"))
                    {
                        part.ExhibitsTraits.Add("is.partition.format.parquet", false);
                    }
                    //default is csv
                    else
                    {
                        // Add trait to partition for csv params
                        var csvTrait = part.ExhibitsTraits.Add("is.partition.format.CSV", false);
                        csvTrait.Arguments.Add("columnHeaders", "false");
                        csvTrait.Arguments.Add("delimiter", ",");
                    }
                }
            }
            Console.WriteLine("Save the documents");
            // We can save the documents as manifest.cdm.json format or model.json
            // Save as manifest.cdm.json
            manifestCreated = await manifestResolved.SaveAsAsync($"{manifestName}.manifest.cdm.json", true);
            // Save as a model.json
            // await manifestResolved.SaveAsAsync("model.json", true);
            return manifestCreated;
        }
        public static CdmManifestDeclarationDefinition CreateSubManifestDefinition(CdmCorpusDefinition cdmCorpus, string nextFolder)
        {
            var subManifest = cdmCorpus.MakeObject<CdmManifestDeclarationDefinition>(CdmObjectType.ManifestDeclarationDef, nextFolder, simpleNameRef: false);
            subManifest.ManifestName = nextFolder;
            subManifest.Definition = $"{nextFolder}/{nextFolder}.manifest.cdm.json";

            return subManifest;
        }
        private static CdmTypeAttributeDefinition CreateEntityAttributeWithPurposeAndDataType(CdmCorpusDefinition cdmCorpus, string attributeName, string purpose, string dataType)
        {
            var entityAttribute = CreateEntityAttributeWithPurpose(cdmCorpus, attributeName, purpose);
            entityAttribute.DataType = cdmCorpus.MakeRef<CdmDataTypeReference>(CdmObjectType.DataTypeRef, dataType, true);

            return entityAttribute;
        }

        /// <summary>
        /// Create an type attribute definition instance with provided purpose.
        /// </summary>
        /// <param name="cdmCorpus"> The CDM corpus. </param>
        /// <param name="attributeName"> The directives to use while getting the resolved entities. </param>
        /// <param name="purpose"> The manifest to be resolved. </param>
        /// <returns> The instance of type attribute definition. </returns>
        private static CdmTypeAttributeDefinition CreateEntityAttributeWithPurpose(CdmCorpusDefinition cdmCorpus, string attributeName, string purpose)
        {
            var entityAttribute = cdmCorpus.MakeObject<CdmTypeAttributeDefinition>(CdmObjectType.TypeAttributeDef, attributeName, false);
            entityAttribute.Purpose = cdmCorpus.MakeRef<CdmPurposeReference>(CdmObjectType.PurposeRef, purpose, true);
            return entityAttribute;

        }
        private async static void addExistingEntity(CdmCorpusDefinition cdmCorpus, string manifestName, CdmManifestDefinition manifestDefinition)
        {
            CdmManifestDefinition manifest = await cdmCorpus.FetchObjectAsync<CdmManifestDefinition>(manifestName + ".manifest.cdm.json");
            if (manifest != null)
            {
                foreach (CdmEntityDeclarationDefinition eDef in manifest.Entities)
                {
                    // Create the entity definition instance
                    var entity = cdmCorpus.MakeObject<CdmEntityDefinition>(CdmObjectType.EntityDef, eDef.EntityName, false);
                    // Add properties to the entity instance
                    entity.DisplayName = eDef.EntityName;
                    entity.Version = "1.0.0";
                    entity.Description = eDef.EntityName;
                    //manifestAbstract.Entities.Add(entity.EntityName, $"resolved/{eDef.EntityName}.cdm.json/{eDef.EntityName}");


                    var entSelected = await cdmCorpus.FetchObjectAsync<CdmEntityDefinition>(eDef.EntityPath, manifest);
                    foreach (CdmTypeAttributeDefinition attribute in entSelected.Attributes)

                    {
                        //var attributes = CreateEntityAttributeWithPurposeAndDataType(cdmCorpus, attribute.Name, "hasA", attribute.DataType);
                        entity.Attributes.Add(attribute);
                    }
                    // Create the document which contains the entity
                    var entityDoc = cdmCorpus.MakeObject<CdmDocumentDefinition>(CdmObjectType.DocumentDef, $"{eDef.EntityName}.cdm.json", false);
                    // Add an import to the foundations doc so the traits about partitons will resolve nicely
                    entityDoc.Imports.Add(FoundationJsonPath);
                    entityDoc.Definitions.Add(entity);
                    // Add the document to the root of the local documents in the corpus
                    var localRoot = cdmCorpus.Storage.FetchRootFolder("local");
                    localRoot.Documents.Add(entityDoc, entityDoc.Name);
                    manifestDefinition.Entities.Add(entity);

                }

            }
        }
        public async static Task<ManifestDefinitions> getManifestDefinition(string artifactsFile, string tableList)
        {
            using (StreamReader r = new StreamReader(artifactsFile))
            {
                string artifactsStr = await r.ReadToEndAsync();
                var artifacts = JsonConvert.DeserializeObject<List<Artifacts>>(artifactsStr);
                string[] tables = tableList.Split(',');
                List<ManifestDefinition> ManifestDefinitions = new List<ManifestDefinition>();

                foreach (string table in tables)
                {
                    string tableName, key, value, manifestName, manifestLocation;

                    tableName = table.Trim();
                    key = "tables:" + tableName.ToLower();

                    var artifact = artifacts.Find(x => x.Key.ToLower().Equals(key));

                    if (artifact != null)
                    {
                        value = artifact.Value;
                    }
                    else
                    {
                        value = "Tables/Custom/" + tableName;
                    }
                    manifestLocation = value.Substring(0, (value.Length - (tableName.Length + 1)));
                    manifestName = manifestLocation.Substring(manifestLocation.LastIndexOf('/') + 1);

                    ManifestDefinition md = new ManifestDefinition();
                    md.TableName = tableName;
                    md.DataLocation = value;
                    md.ManifestLocation = manifestLocation;
                    md.ManifestName = manifestName;

                    ManifestDefinitions.Add(md);
                }
                var grouped = ManifestDefinitions.GroupBy(c => new { c.ManifestLocation, c.ManifestName })
                                                 .Select(g => new
                                                 {
                                                     ManifestLocation = g.Key.ManifestLocation,
                                                     ManifestName = g.Key.ManifestName,
                                                     Tables = g.Select(table => new { table.TableName })
                                                 });

                var mds = new ManifestDefinitions() { Tables = ManifestDefinitions, Manifests = grouped };

                return mds;
            }
        }
        public async static Task<bool> manifestToSQL(AdlsContext adlsContext, string manifestName, string localRoot, List<SQLStatement> statemensList)
        {
            ManifestHandler manifestHandler = new ManifestHandler(adlsContext, localRoot);
            CdmManifestDefinition manifest = await manifestHandler.cdmCorpus.FetchObjectAsync<CdmManifestDefinition>(manifestName + ".manifest.cdm.json");
                     
            foreach (var submanifest in manifest.SubManifests)
            {
                string subManifestName = submanifest.ManifestName;

                await manifestToSQL(adlsContext, subManifestName, localRoot + '/' + subManifestName, statemensList);
                
            }
            
            foreach (CdmEntityDeclarationDefinition eDef in manifest.Entities)
            {
                string entityName = eDef.EntityName;
                string dataLocation = eDef.DataPartitions[0].Location;

                string local = $"Https://{adlsContext.StorageAccount}{adlsContext.FileSytemName}{localRoot}";
                dataLocation = dataLocation.Replace("local:", local);
                var entSelected = await manifestHandler.cdmCorpus.FetchObjectAsync<CdmEntityDefinition>(eDef.EntityPath, manifest);
                string columnDef = "";

                foreach (CdmTypeAttributeDefinition attribute in entSelected.Attributes)
                {
                    string dataType = cdmToSQLDataType(attribute.DataFormat.ToString());

                    if (columnDef == "")
                    {
                        columnDef = $"{attribute.Name} {dataType}";
                    }
                    else
                    {
                        columnDef += $",{attribute.Name} {dataType}";
                    }
                }

                var sql = $"CREATE OR ALTER VIEW {entityName} AS SELECT * FROM OPENROWSET(BULK '{dataLocation}', FORMAT = 'CSV', Parser_Version = '2.0') WITH({columnDef}) as r ";
                statemensList.Add(new SQLStatement() { Statement = sql });
            }
            return true;
                    
        }

            static string cdmToSQLDataType(string dataType)
            {
                string sqlDataType;
                
                switch (dataType)
                {
                    case "bigInteger":
                        sqlDataType = "int64";
                        break;
                    case "integer":
                        sqlDataType = "int";
                        break;
                    case "dateTime":
                        sqlDataType = "DateTime2";
                        break;
                    case "decimal":
                        sqlDataType = "decimal";
                        break;
                    case "double":
                        sqlDataType = "float";
                        break;
                    case "boolean":
                        sqlDataType = "bit";
                        break;
                    default:
                        sqlDataType = "varchar(800)";
                        break;
                }
                return sqlDataType;
            }


        }

}
