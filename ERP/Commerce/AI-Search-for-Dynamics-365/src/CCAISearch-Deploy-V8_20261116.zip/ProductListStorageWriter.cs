using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Identity;
using Azure.Storage.Blobs;
using System.Text.Json;

namespace AISearch.Function
{
    /// <summary>
    /// Converts the D365 product list CSV into JSON files for the Azure AI Search indexer. Converts the VARIANTSJSON column
    /// into a VARIANTS array (SIZE/COLOR/STYLE) matching the Collection(Edm.ComplexType) index field,
    /// plus flat VARIANTCOLORS/VARIANTSIZES/VARIANTSTYLES collections used for scoring and semantic ranking.
    /// Also converts the CATEGORYRECIDSJSON column into the CATEGORYRECIDS collection used for category filters and counts.
    /// Both columns are optional: a CSV without them (older D365 versions) is processed as plain text columns.
    /// </summary>
    public class ProductListStorageWriter
    {
        private const string VariantsJsonColumn = "VARIANTSJSON";
        private const string VariantsField = "VARIANTS";
        private const string CategoryRecIdsJsonColumn = "CATEGORYRECIDSJSON";
        private const string CategoryRecIdsField = "CATEGORYRECIDS";

        private readonly ILogger<ProductListStorageWriter> _logger;

        public ProductListStorageWriter(ILogger<ProductListStorageWriter> logger)
        {
            _logger = logger;
        }

        [Function("ProductListStorageWriter")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
        {
            _logger.LogInformation("C# ProductListStorageWriter function processed a request.");

            FunctionInput input;
            try
            {
                input = await ParseRequestAsync(req);
            }
            catch (Exception ex) when (ex is InvalidOperationException or JsonException)
            {
                var bad = req.CreateResponse(System.Net.HttpStatusCode.BadRequest);
                await bad.WriteStringAsync(ex.Message);
                return bad;
            }

            using var csvStream = await DownloadCsvAsync(input.SourceBlobUrl);
            var (records, files, invalidVariants) = await ParseCsvAndUploadChunksAsync(csvStream, input);

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync(
                $"Successfully processed {records} records into {files} JSON files. Invalid variant JSON rows: {invalidVariants}.");
            return response;
        }

        private static async Task<FunctionInput> ParseRequestAsync(HttpRequestData req)
        {
            var requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            if (string.IsNullOrWhiteSpace(requestBody))
            {
                throw new InvalidOperationException("Request body is empty.");
            }

            var input = JsonSerializer.Deserialize<FunctionInput>(requestBody)
                ?? throw new InvalidOperationException("Invalid JSON format.");

            if (string.IsNullOrWhiteSpace(input.SourceBlobUrl) ||
                string.IsNullOrWhiteSpace(input.DestinationContainer) ||
                string.IsNullOrWhiteSpace(input.DestinationConnectionString))
            {
                throw new InvalidOperationException("Missing required fields: 'sourceBlobUrl', 'destinationContainer' or 'destinationConnectionString'.");
            }

            input.Separator = string.IsNullOrEmpty(input.Separator) ? "," : input.Separator;
            input.BaseFileName = string.IsNullOrWhiteSpace(input.BaseFileName) ? "s" : input.BaseFileName;
            input.RecordsPerFile = input.RecordsPerFile > 0 ? input.RecordsPerFile : 1000;
            return input;
        }

        private static async Task<Stream> DownloadCsvAsync(string sourceBlobUrl)
        {
            using var httpClient = new HttpClient();
            var response = await httpClient.GetAsync(sourceBlobUrl);
            if (!response.IsSuccessStatusCode)
            {
                throw new InvalidOperationException($"Failed to download CSV. Status: {response.StatusCode}");
            }

            var memoryStream = new MemoryStream();
            await response.Content.CopyToAsync(memoryStream);
            memoryStream.Position = 0;
            return memoryStream;
        }

        private async Task<(int Records, int Files, int InvalidVariants)> ParseCsvAndUploadChunksAsync(Stream csvStream, FunctionInput input)
        {
            using var reader = new StreamReader(csvStream, detectEncodingFromByteOrderMarks: true);
            string? headerLine = await reader.ReadLineAsync();
            if (string.IsNullOrWhiteSpace(headerLine))
            {
                throw new InvalidOperationException("CSV file has no headers.");
            }

            var headers = headerLine.Split(input.Separator).Select(h => h.Trim()).ToArray();
            int variantsIndex = Array.FindIndex(headers, h => h.Equals(VariantsJsonColumn, StringComparison.OrdinalIgnoreCase));
            int categoryRecIdsIndex = Array.FindIndex(headers, h => h.Equals(CategoryRecIdsJsonColumn, StringComparison.OrdinalIgnoreCase));

            // DestinationConnectionString carries only the blob endpoint URL; auth uses managed identity.
            var blobServiceClient = new BlobServiceClient(new Uri(input.DestinationConnectionString), new DefaultAzureCredential());
            var containerClient = blobServiceClient.GetBlobContainerClient(input.DestinationContainer);
            await containerClient.CreateIfNotExistsAsync();

            if (input.ResetContainer == "true")
            {
                _logger.LogInformation("Resetting container: {Container}", input.DestinationContainer);
                await foreach (var blobItem in containerClient.GetBlobsAsync())
                {
                    await containerClient.DeleteBlobIfExistsAsync(blobItem.Name);
                }
            }

            var currentChunk = new List<Dictionary<string, object?>>();
            int chunkIndex = 1, recordCount = 0, invalidVariants = 0;
            string? line;

            while ((line = await reader.ReadLineAsync()) != null)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                var values = SplitLine(line, input.Separator, headers.Length, variantsIndex);
                var record = new Dictionary<string, object?>();

                for (int i = 0; i < headers.Length; i++)
                {
                    var value = i < values.Length ? values[i].Trim() : string.Empty;
                    if (i == variantsIndex)
                    {
                        if (!TryParseVariants(value, out var variants))
                        {
                            invalidVariants++;
                            _logger.LogWarning("Invalid variant JSON for record {Key}; indexing without variants.",
                                values.Length > 0 ? values[0] : "?");
                        }
                        record[VariantsField] = variants;
                        // Flat, searchable copies so scoring and the semantic ranker can use variant values.
                        record["VARIANTCOLORS"] = DistinctValues(variants, "COLOR");
                        record["VARIANTSIZES"] = DistinctValues(variants, "SIZE");
                        record["VARIANTSTYLES"] = DistinctValues(variants, "STYLE");
                    }
                    else if (i == categoryRecIdsIndex)
                    {
                        if (!TryParseCategoryRecIds(value, out var categoryRecIds))
                        {
                            _logger.LogWarning("Invalid category RecId JSON for record {Key}; indexing without categories.",
                                values.Length > 0 ? values[0] : "?");
                        }
                        record[CategoryRecIdsField] = categoryRecIds;
                    }
                    else
                    {
                        record[headers[i]] = value;
                    }
                }

                currentChunk.Add(record);
                recordCount++;

                if (currentChunk.Count >= input.RecordsPerFile)
                {
                    await UploadJsonChunkAsync(currentChunk, containerClient, input.BaseFileName, chunkIndex++);
                    currentChunk.Clear();
                }
            }

            if (currentChunk.Count > 0)
            {
                await UploadJsonChunkAsync(currentChunk, containerClient, input.BaseFileName, chunkIndex++);
            }

            return (recordCount, chunkIndex - 1, invalidVariants);
        }

        /// <summary>
        /// Splits a line while keeping the VARIANTSJSON column intact if its JSON contains the separator.
        /// Extra fields are folded back into the variants column; columns before/after it keep their positions.
        /// </summary>
        internal static string[] SplitLine(string line, string separator, int headerCount, int variantsIndex)
        {
            var parts = line.Split(separator);
            if (variantsIndex < 0 || parts.Length <= headerCount)
            {
                return parts;
            }

            int columnsAfter = headerCount - 1 - variantsIndex;
            int variantsEnd = parts.Length - columnsAfter;
            var result = new string[headerCount];

            Array.Copy(parts, 0, result, 0, variantsIndex);
            result[variantsIndex] = string.Join(separator, parts, variantsIndex, variantsEnd - variantsIndex);
            Array.Copy(parts, variantsEnd, result, variantsIndex + 1, columnsAfter);
            return result;
        }

        internal static bool TryParseVariants(string json, out List<Dictionary<string, string>> variants)
        {
            variants = new List<Dictionary<string, string>>();
            if (string.IsNullOrWhiteSpace(json))
            {
                return true;
            }

            try
            {
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.ValueKind != JsonValueKind.Array)
                {
                    return false;
                }

                foreach (var element in doc.RootElement.EnumerateArray())
                {
                    if (element.ValueKind != JsonValueKind.Object) continue;
                    variants.Add(new Dictionary<string, string>
                    {
                        ["SIZE"] = ReadString(element, "SIZE"),
                        ["COLOR"] = ReadString(element, "COLOR"),
                        ["STYLE"] = ReadString(element, "STYLE"),
                    });
                }
                return true;
            }
            catch (JsonException)
            {
                variants.Clear();
                return false;
            }
        }

        /// <summary>
        /// Parses the CATEGORYRECIDSJSON column (a JSON number array) into the CATEGORYRECIDS index field.
        /// </summary>
        internal static bool TryParseCategoryRecIds(string json, out List<long> recIds)
        {
            recIds = new List<long>();
            if (string.IsNullOrWhiteSpace(json))
            {
                return true;
            }

            try
            {
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.ValueKind != JsonValueKind.Array)
                {
                    return false;
                }

                foreach (var element in doc.RootElement.EnumerateArray())
                {
                    if (element.ValueKind == JsonValueKind.Number && element.TryGetInt64(out var recId))
                    {
                        recIds.Add(recId);
                    }
                }
                recIds = recIds.Distinct().ToList();
                return true;
            }
            catch (JsonException)
            {
                recIds.Clear();
                return false;
            }
        }

        internal static List<string> DistinctValues(List<Dictionary<string, string>> variants, string dimension) =>
            variants.Select(v => v[dimension])
                    .Where(v => !string.IsNullOrWhiteSpace(v))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();

        private static string ReadString(JsonElement element, string name) =>
            element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
                ? value.GetString()?.Trim() ?? string.Empty
                : string.Empty;

        private static async Task UploadJsonChunkAsync(
            List<Dictionary<string, object?>> chunk,
            BlobContainerClient containerClient,
            string baseFileName,
            int chunkIndex)
        {
            string timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");
            string fileName = $"{baseFileName}-{chunkIndex}-{timestamp}.json";

            var json = JsonSerializer.Serialize(chunk, new JsonSerializerOptions { WriteIndented = true });
            using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(json));
            await containerClient.GetBlobClient(fileName).UploadAsync(stream, overwrite: true);
        }

        public class FunctionInput
        {
            public required string SourceBlobUrl { get; set; }
            public required string DestinationContainer { get; set; }
            public required string DestinationConnectionString { get; set; } // carries the blob endpoint URL (not a secret)
            public string Separator { get; set; } = ",";
            public int RecordsPerFile { get; set; } = 1000;
            public string BaseFileName { get; set; } = "s";
            public string ResetContainer { get; set; } = "false";
        }    }
}
