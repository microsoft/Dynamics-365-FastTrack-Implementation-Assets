using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Azure.Storage.Blobs;
using Azure.Identity;
using Microsoft.Azure.Functions.Worker.Http;
using System.Text.Json;

namespace AISearch.Function
{
    public class ProductListStorageWriter
    {
        private readonly ILogger<ProductListStorageWriter> _logger;

        public ProductListStorageWriter(ILogger<ProductListStorageWriter> logger)
        {
            _logger = logger;
        }

        [Function("ProductListStorageWriter")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
        {
            _logger.LogInformation("C# ProductListStorageWriter function processed a request.");
            // 1. Read and validate request input
            var input = await ParseRequestAsync(req);

            // 2. Download CSV data from source blob URL
            var csvStream = await DownloadCsvAsync(input.SourceBlobUrl);

            // 3. Parse CSV into chunks AND UPLOAD JSON to blob storage
            await ParseCsvAndUploadChunksAsync(csvStream, input.Separator, input.RecordsPerFile, input);


            // 5. Return a response
            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync($"Successfully processed and uploaded JSON files.");
            return response;
            
        }
        private async Task<FunctionInput> ParseRequestAsync(HttpRequestData req)
        {
            // Read and deserialize request body into FunctionInput
            var requestBody = await new StreamReader(req.Body).ReadToEndAsync();

            if (string.IsNullOrWhiteSpace(requestBody))
            {
                throw new InvalidOperationException("Request body is empty.");
            }

            FunctionInput? input = JsonSerializer.Deserialize<FunctionInput>(requestBody);

            if (input == null)
            {
                throw new InvalidOperationException("Invalid JSON format.");
            }

            // Validate required fields
            if (string.IsNullOrWhiteSpace(input.SourceBlobUrl) ||
                string.IsNullOrWhiteSpace(input.DestinationContainer) ||
                string.IsNullOrWhiteSpace(input.DestinationConnectionString))
            {
                throw new InvalidOperationException("Missing required fields: 'sourceBlobUrl', 'destinationContainer' or 'destinationConnectionString'.");
            }

            // Set defaults for optional fields
            input.Separator ??= ",";
            input.BaseFileName ??= "s";
            input.RecordsPerFile = input.RecordsPerFile > 0 ? input.RecordsPerFile : 1000;

            return input;
        }

        private async Task<Stream> DownloadCsvAsync(string sourceBlobUrl)
        {
            // Download CSV content using HttpClient
            if (string.IsNullOrWhiteSpace(sourceBlobUrl))
            {
                throw new ArgumentException("sourceBlobUrl cannot be null or empty.");
            }

            using var httpClient = new HttpClient();

            try
            {
                var response = await httpClient.GetAsync(sourceBlobUrl);

                if (!response.IsSuccessStatusCode)
                {
                    throw new InvalidOperationException($"Failed to download CSV. Status: {response.StatusCode}");
                }

                // Read stream and copy to memory so it's seekable (important for later parsing)
                var networkStream = await response.Content.ReadAsStreamAsync();
                var memoryStream = new MemoryStream();
                await networkStream.CopyToAsync(memoryStream);
                
                memoryStream.Position = 0;

                return memoryStream;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error occurred while downloading the CSV stream: " + ex.Message, ex);
            }
        }

        private async Task ParseCsvAndUploadChunksAsync(
            Stream csvStream, 
            string separator, 
            int recordsPerFile, 
            FunctionInput input)
        {
            using var reader = new StreamReader(csvStream);
            string? headerLine = await reader.ReadLineAsync();

            if (string.IsNullOrWhiteSpace(headerLine))
            {
                throw new InvalidOperationException("CSV file has no headers.");
            }

            var headers = headerLine.Split(separator);

            var currentChunk = new List<Dictionary<string, string>>();
            int chunkIndex = 1;

            // 'DestinationConnectionString' carries only the blob endpoint URL (a non-secret
            // value, e.g. https://<account>.blob.core.windows.net) — D365 parses it out of the
            // storage connection string and never sends the account key. Authentication to
            // storage uses the Function App's managed identity (DefaultAzureCredential).
            var blobServiceClient = new BlobServiceClient(new Uri(input.DestinationConnectionString), new DefaultAzureCredential());
            var containerClient = blobServiceClient.GetBlobContainerClient(input.DestinationContainer);

            await containerClient.CreateIfNotExistsAsync();
            // 🔁 Reset: Delete all blobs if requested
            if (input.ResetContainer == "true")
            {
                // Delete all blobs in the container
                _logger.LogInformation($"Resetting container: {input.DestinationContainer}");
                {
                    await foreach (var blobItem in containerClient.GetBlobsAsync())
                    {
                        await containerClient.DeleteBlobIfExistsAsync(blobItem.Name);
                    }
                }
            }
            string? line;
            while ((line = await reader.ReadLineAsync()) != null)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                var values = line.Split(separator);
                var record = new Dictionary<string, string>();

                for (int i = 0; i < headers.Length; i++)
                {
                    var key = headers[i].Trim();
                    var value = i < values.Length ? values[i].Trim() : string.Empty;                                       
                    record[key] = value;
                
                    
                }

                currentChunk.Add(record);

                if (currentChunk.Count >= recordsPerFile)
                {
                    await UploadJsonChunkAsync(currentChunk, containerClient, input.BaseFileName, chunkIndex++);
                    currentChunk.Clear();
                }
            }

            // Upload remaining records
            if (currentChunk.Count > 0)
            {
                await UploadJsonChunkAsync(currentChunk, containerClient, input.BaseFileName, chunkIndex++);
            }
        }



    private async Task UploadJsonChunkAsync(
        List<Dictionary<string, string>> chunk, 
        BlobContainerClient containerClient, 
        string baseFileName, 
        int chunkIndex)
    {
        string timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");
        string fileName = $"{baseFileName}-{chunkIndex}-{timestamp}.json";

        var json = JsonSerializer.Serialize(chunk, new JsonSerializerOptions { WriteIndented = true });

        using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(json));
        var blobClient = containerClient.GetBlobClient(fileName);

        await blobClient.UploadAsync(stream, overwrite: true);
    }


        public class FunctionInput
        {
            public required string SourceBlobUrl { get; set; }
            public required string DestinationContainer { get; set; }
            public required string DestinationConnectionString { get; set; } // carries the blob endpoint URL (not a secret)
            public string Separator { get; set; } = ","; // default value
            public int RecordsPerFile { get; set; } = 1000; // default value
            public string BaseFileName { get; set; } = "s"; // default value
            public string ResetContainer { get; set; } = "false"; // ✅ New property
        }
    }
}
