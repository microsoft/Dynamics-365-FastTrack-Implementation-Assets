IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'p_msdyn_URS_Ping')
    DROP PROCEDURE [dbo].[p_msdyn_URS_Ping]
GO

CREATE PROCEDURE [dbo].p_msdyn_URS_Ping
    @BatchSize INT,
    @BatchStart INT
AS
BEGIN
    LINENO 0;
    -- This stored proc exists just so we can run a simple test to confirm
    -- that stored procs were imported, and that the plugin can be used
    -- to invoke them.
    -- See IntegrationTests/UpgradeTests.cs
    SAVE TRANSACTION SavePoint
    SET NOCOUNT ON

    BEGIN TRY
		IF @BatchSize < 0
		BEGIN 
			THROW 51000, 'testing', 1;
		END
        SELECT 'ping ' + 
            CONVERT(VARCHAR(MAX), @BatchSize) + ' ' + 
            CONVERT(VARCHAR(MAX), @BatchStart)
    END TRY
    BEGIN CATCH
		ROLLBACK TRANSACTION SavePoint;
		SELECT 'error:' + CONVERT(VARCHAR(MAX), ERROR_PROCEDURE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_NUMBER())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_LINE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_MESSAGE())
    END CATCH
END
