﻿IF EXISTS (SELECT * FROM sys.procedures WHERE NAME = 'p_msdyn_URS_513_PotassiumUR2ToUR3_UpdateProposedDuration')
BEGIN
    DROP PROCEDURE [dbo].p_msdyn_URS_513_PotassiumUR2ToUR3_UpdateProposedDuration
END
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].p_msdyn_URS_513_PotassiumUR2ToUR3_UpdateProposedDuration
    @BatchSize INT,
    @BatchStart INT
AS
BEGIN
    LINENO 0;
    -- Based on 
    -- URS action URSUpgradeJobID.UpgradeScripts_PotassiumUR2ToUR3_UpdateProposedDuration (513)
    -- file: /Solutions/MicrosoftDynamicsScheduling/Fps/Fps/Actions/FpsActionJobs/URSUpgradeJobs.cs
	-- method: PotassiumUR2ToUR3UpdateProposedDuration()

    SAVE TRANSACTION SavePoint
    SET NOCOUNT ON

    BEGIN TRY
        DECLARE @BookingStatusStatus_Proposed INT = 1;
        DECLARE @BookingStatusStatus_Committed INT = 2;
        DECLARE @BookableResourceResourceType_Generic INT = 1;
	    DECLARE @BookableResourceGenericType_ServiceCenter INT = 690970000;

	    -- Update Fulfilled Duration and Proposed Duration on Resource Requirements.
	    
        -- Create temp table to hold resource requirement, duration, 
        -- fulfilled duration, remaining duration, and proposed duration.
        -- To process rows in batches, we use ROW_NUMBER() and the @BatchSize and @BatchStart parameters
	    CREATE TABLE #resourceRequirementWithDuration
	    (	msdyn_resourcerequirementId UNIQUEIDENTIFIER NOT NULL,
		    msdyn_duration INT,
		    msdyn_FulfilledDuration INT,
		    msdyn_RemainingDuration INT,
            msdyn_ProposedDuration INT,
			INDEX IX_ResourceRequirementId (msdyn_resourcerequirementId));

	    INSERT INTO #resourceRequirementWithDuration (msdyn_resourcerequirementId, msdyn_duration)
		    SELECT N.msdyn_resourcerequirementId, N.msdyn_duration
            FROM (
                SELECT 
                    msdyn_resourcerequirementId, msdyn_duration,
                    ROW_NUMBER() OVER (ORDER BY msdyn_resourcerequirementId) AS RowNum
                FROM msdyn_resourcerequirementBase
            ) N
		    WHERE N.RowNum BETWEEN @BatchStart AND @BatchStart + @BatchSize - 1

	    -- Sum duration from all bookings for each resource requirement
		CREATE TABLE #resourceRequirementWithFulfilledAndProposedDuration (
			msdyn_resourcerequirementId UNIQUEIDENTIFIER,
			msdyn_FulfilledDuration INT,
			msdyn_ProposedDuration INT,
			INDEX IX_ResourceRequirementID (msdyn_resourcerequirementId)
		);
		INSERT INTO #resourceRequirementWithFulfilledAndProposedDuration
	    SELECT
            msdyn_ResourceRequirement as msdyn_resourcerequirementId,
            SUM(
			    CASE
			    WHEN BS.Status = @BookingStatusStatus_Committed
                    AND Duration IS NOT NULL AND Duration > 0 THEN
			    (
				    CASE
					    WHEN msdyn_ActualTravelDuration IS NOT NULL
						    THEN
						    (
							    CASE 
								    WHEN Duration < msdyn_ActualTravelDuration 
									    THEN 0
								    ELSE 
									    Duration - msdyn_ActualTravelDuration
							    END
						    )
					    WHEN msdyn_EstimatedTravelDuration IS NOT NULL
						    THEN
						    (
							    CASE 
								    WHEN Duration < msdyn_EstimatedTravelDuration 
									    THEN 0
								    ELSE 
									    Duration - msdyn_EstimatedTravelDuration
							    END
						    )
					    ELSE
						    Duration
				    END
			    )
			    ELSE
				    0
			    END
		    ) AS msdyn_FulfilledDuration,
            SUM(
			    CASE
			    WHEN BS.Status = @BookingStatusStatus_Proposed
                    AND Duration IS NOT NULL AND Duration > 0 THEN
			    (
				    CASE
					    WHEN msdyn_ActualTravelDuration IS NOT NULL
						    THEN
						    (
							    CASE 
								    WHEN Duration < msdyn_ActualTravelDuration 
									    THEN 0
								    ELSE 
									    Duration - msdyn_ActualTravelDuration
							    END
						    )
					    WHEN msdyn_EstimatedTravelDuration IS NOT NULL
						    THEN
						    (
							    CASE 
								    WHEN Duration < msdyn_EstimatedTravelDuration 
									    THEN 0
								    ELSE 
									    Duration - msdyn_EstimatedTravelDuration
							    END
						    )
					    ELSE
						    Duration
				    END
			    )
			    ELSE
				    0
			    END
		    ) AS msdyn_ProposedDuration
		    FROM BookableResourceBookingBase BRB
		        INNER JOIN BookingStatusBase BS ON BS.BookingStatusId = BRB.BookingStatus
		        INNER JOIN BookableResourceBase BR ON BR.BookableResourceId = BRB.Resource
                INNER JOIN #resourceRequirementWithDuration RRWD ON RRWD.msdyn_resourcerequirementId = BRB.msdyn_ResourceRequirement
		    WHERE msdyn_ResourceRequirement IS NOT NULL
		        AND BRB.StateCode = 0
		        AND (BS.Status = @BookingStatusStatus_Committed OR BS.Status = @BookingStatusStatus_Proposed)
		        AND (BR.ResourceType <> @BookableResourceResourceType_Generic
                     OR BR.msdyn_GenericType = @BookableResourceGenericType_ServiceCenter)
		    GROUP BY msdyn_ResourceRequirement

	    -- Update fulfilled duration and proposed duration for each resource requirement
	    UPDATE #resourceRequirementWithDuration
		    SET msdyn_FulfilledDuration = RRFPD.msdyn_FulfilledDuration,
                msdyn_ProposedDuration = RRFPD.msdyn_ProposedDuration
		    FROM #resourceRequirementWithFulfilledAndProposedDuration RRFPD
		    WHERE RRFPD.msdyn_resourcerequirementId = #resourceRequirementWithDuration.msdyn_resourcerequirementId
		
	    -- Update remaining duration for each resource requirement
	    -- Set fulfilled duration to 0 if null
	    -- Set remaining duration to 0 if null
        -- Set proposed duration to 0 if null
	    UPDATE #resourceRequirementWithDuration
		    SET msdyn_FulfilledDuration = ISNULL(msdyn_FulfilledDuration, 0),
			    msdyn_RemainingDuration = msdyn_duration - ISNULL(msdyn_FulfilledDuration, 0)

	    UPDATE #resourceRequirementWithDuration
		    SET msdyn_RemainingDuration = 0
		    WHERE msdyn_RemainingDuration < 0 OR msdyn_RemainingDuration IS NULL

        UPDATE #resourceRequirementWithDuration
            SET msdyn_ProposedDuration = 0
            WHERE msdyn_ProposedDuration < 0 OR msdyn_ProposedDuration IS NULL

	    -- Update the real resource requirement table
	    UPDATE msdyn_resourcerequirementBase
		    SET msdyn_FulfilledDuration = RRWD.msdyn_FulfilledDuration,
			    msdyn_RemainingDuration = RRWD.msdyn_RemainingDuration,
                msdyn_ProposedDuration = RRWD.msdyn_ProposedDuration,
			    ModifiedOn = GETDATE()
		    FROM #resourceRequirementWithDuration RRWD
		    WHERE RRWD.msdyn_resourcerequirementId = msdyn_resourcerequirementBase.msdyn_resourcerequirementId

        SELECT 'success: ' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ':'
            + 'updated ' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ' msdyn_resourcerequirement'
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION SavePoint;
		SELECT 'error:' + CONVERT(VARCHAR(MAX), ERROR_PROCEDURE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_NUMBER())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_LINE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_MESSAGE())
    END CATCH
END
