﻿IF EXISTS (SELECT * FROM sys.procedures WHERE NAME = 'p_msdyn_URS_613_PotassiumToCalcium_UpdateBookingWorkLocation')
BEGIN
    DROP PROCEDURE [dbo].p_msdyn_URS_613_PotassiumToCalcium_UpdateBookingWorkLocation
END
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].p_msdyn_URS_613_PotassiumToCalcium_UpdateBookingWorkLocation
    @BatchSize INT,
    @BatchStart INT
AS
BEGIN
    -- Based on 
    -- URS action URSUpgradeJobID.UpgradeScripts_JanToFebPatch_UpdateResource (613)
    -- File: /Solutions/MicrosoftDynamicsScheduling/Fps/Fps/Actions/FpsActionJobs/URSUpgradeJobs.cs
    -- Method: PotassiumToCalciumSetWorkLocationOnBooking()

	LINENO 0;
    SAVE TRANSACTION SavePoint
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE @Total_Updates INT = 0;

		UPDATE TOP (@BatchSize) BookableResourceBookingBase
		SET msdyn_WorkLocation = '690970000'
		WHERE msdyn_WorkLocation IS NULL
		AND msdyn_Latitude IS NOT NULL AND msdyn_Longitude IS NOT NULL;
		
		SET @Total_Updates = @@ROWCOUNT;

		UPDATE TOP (@BatchSize) BookableResourceBookingBase
		SET msdyn_WorkLocation = rrb.msdyn_WorkLocation
		FROM msdyn_resourcerequirementBase rrb
		WHERE BookableResourceBookingBase.msdyn_ResourceRequirement IS NOT NULL
		AND rrb.msdyn_resourcerequirementId = BookableResourceBookingBase.msdyn_ResourceRequirement
		AND BookableResourceBookingBase.msdyn_WorkLocation IS NULL
		AND rrb.msdyn_WorkLocation IS NOT NULL;
		
		SET @Total_Updates = @Total_Updates + @@ROWCOUNT;

		SELECT 'success:' + CONVERT(VARCHAR(MAX), @Total_Updates) + ':'
            + 'updated ' + CONVERT(VARCHAR(MAX), @Total_Updates) + ' BookableResourceBooking'
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION SavePoint;
		SELECT 'error:' + CONVERT(VARCHAR(MAX), ERROR_PROCEDURE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_NUMBER())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_LINE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_MESSAGE())
    END CATCH
END
