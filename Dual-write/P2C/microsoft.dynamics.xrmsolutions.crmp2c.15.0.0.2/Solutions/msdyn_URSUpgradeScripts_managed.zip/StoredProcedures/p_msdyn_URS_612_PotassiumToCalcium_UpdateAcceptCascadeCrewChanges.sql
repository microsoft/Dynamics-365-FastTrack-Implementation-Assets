﻿IF EXISTS (SELECT * FROM sys.procedures WHERE NAME = 'p_msdyn_URS_612_PotassiumToCalcium_UpdateAcceptCascadeCrewChanges')
BEGIN
    DROP PROCEDURE [dbo].p_msdyn_URS_612_PotassiumToCalcium_UpdateAcceptCascadeCrewChanges
END
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].p_msdyn_URS_612_PotassiumToCalcium_UpdateAcceptCascadeCrewChanges
    @BatchSize INT,
    @BatchStart INT
AS
BEGIN
    -- Based on 
    -- URS action URSUpgradeJobID.UpgradeScripts_PotassiumToCalcium_SetAcceptCascadeCrewChangesOnBooking (612)
    -- File: /Solutions/MicrosoftDynamicsScheduling/Fps/Fps/Actions/FpsActionJobs/URSUpgradeJobs.cs
    -- Method: PotassiumToCalciumSetAcceptCascadeCrewChangesOnBooking()

	LINENO 0;
    SAVE TRANSACTION SavePoint
	SET NOCOUNT ON
    BEGIN TRY
		UPDATE TOP (@BatchSize) BookableResourceBookingBase
		SET msdyn_AcceptCascadeCrewChanges = msdyn_CascadeCrewChanges
		WHERE msdyn_CascadeCrewChanges IS NOT NULL
		AND msdyn_AcceptCascadeCrewChanges IS NULL;
		
		SELECT 'success:' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ':'
            + 'updated ' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ' BookableResourceBooking'
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION SavePoint;
		SELECT 'error:' + CONVERT(VARCHAR(MAX), ERROR_PROCEDURE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_NUMBER())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_LINE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_MESSAGE())
    END CATCH
END