﻿IF EXISTS (SELECT * FROM sys.procedures WHERE NAME = 'p_msdyn_URS_505_JanToFebPatch_UpdateResource')
BEGIN
    DROP PROCEDURE [dbo].p_msdyn_URS_505_JanToFebPatch_UpdateResource
END
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].p_msdyn_URS_505_JanToFebPatch_UpdateResource
    @BatchSize INT,
    @BatchStart INT
AS
BEGIN
    LINENO 0;
    -- Based on 
    -- URS action URSUpgradeJobID.UpgradeScripts_JanToFebPatch_UpdateResource (505)
    -- File: /Solutions/MicrosoftDynamicsScheduling/Fps/Fps/Actions/FpsActionJobs/URSUpgradeJobs.cs
    -- Method: JanToFebUpdateBookableResourceLocation()

    SAVE TRANSACTION SavePoint
    SET NOCOUNT ON
    
    BEGIN TRY
	    DECLARE @RoutingLocationType_Resource			INT = 690970000;
	    DECLARE @RoutingLocationType_Company			INT = 690970001;
        DECLARE @RoutingLocationType_LocationAgnostic	INT = 690970002;

        DECLARE @ResourceType_User		INT = 3;
        DECLARE @ResourceType_Account	INT = 5;
        DECLARE @ResourceType_Contact	INT = 2;
        DECLARE @ResourceType_Generic	INT = 1;
        DECLARE @ResourceType_Equipment INT = 4;
        DECLARE @ResourceType_Group		INT = 6;

	    -- Update Resource Locations

        -- Process in batches using row numbering.
		CREATE TABLE #resourceLocation (
			ResourceId UNIQUEIDENTIFIER NOT NULL,
			OldStartLocation INT,
			OldEndLocation INT,
			NewStartLocation INT,
			NewEndLocation INT,
			INDEX IX_ResourceId (ResourceId));
		INSERT INTO #resourceLocation (ResourceId, OldStartLocation, OldEndLocation)
			SELECT N.BookableResourceId, N.msdyn_StartLocation, N.msdyn_EndLocation 
			FROM (
                SELECT 
                    BookableResourceId, msdyn_StartLocation, msdyn_EndLocation,
                    ROW_NUMBER() OVER (ORDER BY BookableResourceId) AS RowNum
                FROM BookableResourceBase 
    			WHERE msdyn_DisplayOnScheduleAssistant = 1
            ) N
            WHERE N.RowNum BETWEEN @BatchStart AND @BatchStart + @BatchSize - 1

        -- If this query didn't find any rows, then we are done.
        IF @@ROWCOUNT = 0 BEGIN            
            SELECT 'success:0:'; -- 0 means there are no more rows to process
            RETURN;
        END;

		UPDATE #resourceLocation
		SET NewStartLocation = 
		(
			CASE 
				WHEN OldStartLocation = @RoutingLocationType_Company AND OU.msdyn_Latitude IS NOT NULL AND OU.msdyn_Longitude IS NOT NULL
					THEN @RoutingLocationType_Company
				ELSE
					CASE 
						WHEN BR.ResourceType = @ResourceType_Account
							THEN 
								CASE WHEN A.Address1_Latitude IS NOT NULL AND A.Address1_Longitude IS NOT NULL
									THEN @RoutingLocationType_Resource
									ELSE @RoutingLocationType_LocationAgnostic
								END
						WHEN BR.ResourceType = @ResourceType_Contact
							THEN
								CASE WHEN C.Address1_Latitude IS NOT NULL AND C.Address1_Longitude IS NOT NULL
									THEN @RoutingLocationType_Resource
									ELSE @RoutingLocationType_LocationAgnostic
								END
						WHEN BR.ResourceType = @ResourceType_User
							THEN
								CASE WHEN U.Address1_Latitude IS NOT NULL AND U.Address1_Longitude IS NOT NULL
									THEN @RoutingLocationType_Resource
									ELSE @RoutingLocationType_LocationAgnostic
								END
						ELSE
							CASE WHEN OU.msdyn_Latitude IS NOT NULL AND OU.msdyn_Longitude IS NOT NULL
								THEN @RoutingLocationType_Company
								ELSE @RoutingLocationType_LocationAgnostic
							END
					END
			END
		),
		NewEndLocation = 
		(
			CASE 
				WHEN OldEndLocation = @RoutingLocationType_Company AND OU.msdyn_Latitude IS NOT NULL AND OU.msdyn_Longitude IS NOT NULL
					THEN @RoutingLocationType_Company
				ELSE
					CASE 
						WHEN BR.ResourceType = @ResourceType_Account
							THEN 
								CASE WHEN A.Address1_Latitude IS NOT NULL AND A.Address1_Longitude IS NOT NULL
									THEN @RoutingLocationType_Resource
									ELSE @RoutingLocationType_LocationAgnostic
								END
						WHEN BR.ResourceType = @ResourceType_Contact
							THEN
								CASE WHEN C.Address1_Latitude IS NOT NULL AND C.Address1_Longitude IS NOT NULL
									THEN @RoutingLocationType_Resource
									ELSE @RoutingLocationType_LocationAgnostic
								END
						WHEN BR.ResourceType = @ResourceType_User
							THEN
								CASE WHEN U.Address1_Latitude IS NOT NULL AND U.Address1_Longitude IS NOT NULL
									THEN @RoutingLocationType_Resource
									ELSE @RoutingLocationType_LocationAgnostic
								END
						ELSE
							CASE WHEN OU.msdyn_Latitude IS NOT NULL AND OU.msdyn_Longitude IS NOT NULL
								THEN @RoutingLocationType_Company
								ELSE @RoutingLocationType_LocationAgnostic
							END
					END
			END
		)
		FROM BookableResourceBase BR 
		LEFT OUTER JOIN msdyn_organizationalunitBase OU ON OU.msdyn_organizationalunitId = BR.msdyn_organizationalunit
		LEFT OUTER JOIN Account A ON A.AccountId = BR.AccountId
		LEFT OUTER JOIN Contact C ON C.ContactId = BR.ContactId
		LEFT OUTER JOIN SystemUser U ON U.SystemUserId = BR.UserId
		WHERE BR.BookableResourceId = #resourceLocation.ResourceId 

		UPDATE #resourceLocation 
		SET NewStartLocation = @RoutingLocationType_LocationAgnostic, 
			NewEndLocation = @RoutingLocationType_LocationAgnostic
		WHERE NewStartLocation = @RoutingLocationType_LocationAgnostic 
			OR NewEndLocation = @RoutingLocationType_LocationAgnostic

		UPDATE BookableResourceBase 
		SET msdyn_StartLocation = RL.NewStartLocation, 
			msdyn_EndLocation = RL.NewEndLocation,
			ModifiedOn = GETDATE()
		FROM #resourceLocation RL
		WHERE RL.ResourceId = BookableResourceBase.BookableResourceId 
		AND (RL.NewStartLocation != ISNULL(msdyn_StartLocation, -1) OR RL.NewEndLocation != ISNULL(msdyn_EndLocation, -1))

        SELECT 'success:1:'
            + 'updated ' + CONVERT(VARCHAR(MAX), @@ROWCOUNT) + ' BookableResource'
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION SavePoint;
		SELECT 'error:' + CONVERT(VARCHAR(MAX), ERROR_PROCEDURE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_NUMBER())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_LINE())
			+ '|' + CONVERT(VARCHAR(MAX), ERROR_MESSAGE())
    END CATCH
END
