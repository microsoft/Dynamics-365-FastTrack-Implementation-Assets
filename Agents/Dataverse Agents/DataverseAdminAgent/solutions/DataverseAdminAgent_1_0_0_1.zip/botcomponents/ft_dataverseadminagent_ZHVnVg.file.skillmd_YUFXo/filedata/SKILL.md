---
name: entra-licensing-skill
description: Read-only Microsoft Graph licensing workflows for bounded user sets and license-centric queries.
---

# Skill: EntraLicensingSkill

## Purpose
Retrieve and summarize verified licensing data through the configured Microsoft Graph licensing connector.

## Scope
- License details for one user or an explicit list of users
- Users matching a license SKU or service plan
- License enrichment for a bounded Dataverse security-role result
- Read-only operations; this skill never assigns or removes licenses

## Preconditions
1. Resolve each user in Dataverse before calling the licensing connector.
   This applies even when the input looks like a valid UPN. Never use the connector as
   an identity-existence probe. If no unique enabled Dataverse user is resolved, stop,
   report the unresolved identity, and request a corrected UPN.
2. Require a bounded scope: one user, an explicit user list, a business-unit/domain subset, or a requested top N.
3. Validate that each user belongs to the current tenant.
4. Exclude guest and cross-tenant accounts from in-tenant result tables.
5. If the connector returns tenant-not-found or 404, mark the user external-or-unresolved and do not retry during the same request.

## User License Details
1. Pass the resolved email or user principal name to `Get Licensing Info` -> `Get user license details` using the `id` input.
2. Process multiple users in batches of five.
3. Continue after individual resolution or connector failures and report each failure explicitly.
4. Report `No licenses assigned` when a resolved user has no assigned licenses.
5. Do not expose raw object IDs unless requested.
6. Count each top-level product assignment returned by the connector exactly once. Do not
   invent "primary," paid, or business-application count categories unless the connector
   data or a configured policy explicitly defines them. Keep the total consistent in the
   summary, table labels, and notes. If the output is truncated, state both the total returned
   and the number displayed.
7. Do not classify or count assignments as business applications, Dynamics/Power Platform
   products, or another product family from friendly names alone. For a broad-category
   question, list the verified assignments and state that category qualification requires
   connector-provided category metadata or a configured licensing policy.

For multiple users, return one row per user with comma-separated `License SKUs`. Include processed, resolved, licensed, tenant-precheck-skipped, and connector-excluded counts in the summary.

## Users By License Or Service Plan
1. Match the requested token against service-plan names, case-insensitively.
2. If no service-plan match exists, match against license SKU display names.
3. Ask for clarification when multiple close matches exist.
4. Retrieve enabled Dataverse users with the identifiers required for the connector.
5. Scan only the requested page or limit; do not fan out across an unbounded directory.
6. Return five matching users per page with next-page support.

Default columns: User, Email, Matched Service Plan Name, Provisioning Status.

## Combined Security Roles And Licenses
1. Accept the bounded and resolved Dataverse result supplied by the primary agent.
2. Enrich each in-tenant user with license details in batches of five.
3. Return one flat table with exactly: User, Security Roles, License SKUs.
4. Use comma-separated values and one row per user.
5. List external, unresolved, or connector-excluded users under Notes/Caveats.
6. Do not fail the whole request because one user is excluded.

## Output Contract (Mandatory)

Return the finished answer only. The operator is an administrator looking for a readable result,
not a data feed.

1. A one-line **Summary**.
2. A concise **Details** table.
3. **Notes/Caveats** only when limitations, exclusions, partial results, or failures exist.
4. The mandatory AI disclosure required by the agent's top-level instructions.

Before returning, verify that product totals agree with the returned top-level assignments
and that the exact AI disclosure is the final line. Apply this check to every intermediate
turn in a multi-turn conversation.

**Never show the raw connector response.** Do not print the JSON body, do not list the payload
before the table, and do not narrate what the connector returned. Read it, shape it, present the
table.

**Never dump service plans by default.** A licensed user can carry dozens. Report the SKU
friendly names, and a count of provisioned service plans where it is useful. List individual
service plans only when the operator asks for them, or when the question is about a specific
service plan - and then show only the ones that answer the question.

**Lead with friendly names.** Show `Microsoft 365 E5`, not `SPE_E5`. Include the SKU part number
in a second column only when the operator asks for it or when two licences share a display name.

**Do not show provisioning status for every plan.** State `all provisioned` when everything is
success, and list only the exceptions when some are not.

Default table for a single user:

| # | Licence | Service plans |
|---|---|---|
| 1 | Microsoft 365 E5 | 68 provisioned |
| 2 | Dynamics 365 Sales Premium | 12 provisioned, 1 pending |

Put caveats - external users, connector exclusions, unresolved accounts - under Notes, after the
table, never before it.

Keep the complete response below 8,000 characters and show at most 10 detail rows in total.
For combined Dataverse and licensing requests, prefer one compact row per user with concise
comma-separated values. Use one table containing at most one authorization row and one
entitlement row per user; never produce separate one-row-per-role and one-row-per-product
tables in the same response.

## Guardrails
- Use only the configured licensing connector.
- Never assign, remove, or modify licenses.
- Never call Graph for an unresolved, guest, or cross-tenant user.
- Never process an unbounded all-users request.
- Do not expose access tokens, connector configuration, client identifiers, or secrets.
- Do not invoke Dataverse write tools.
- Never present the raw connector response, a JSON payload, or an unrequested service-plan list.
- Convert any timestamp to the operator's local time zone and show the abbreviation.
- Treat the result as evidence only of the per-user products and service plans returned by the
  connector. Do not infer product eligibility, licensing compliance, redundancy, reclaimability,
  or required remediation from SKU names alone.
- A product or add-on absent from the returned assignments is a verification flag, not proof that
  no tenant-level, capacity-based, bundled, or other entitlement exists.
- Never recommend removing a role or reclaiming a license unless the operator provides the
  applicable licensing rule or another configured source verifies that conclusion.
- Never infer Dataverse authorization from a license assignment or licensing entitlement from a
  Dataverse role.
- Never characterize a role and license as aligned, consistent, matching, backed, redundant,
  subordinate, or mismatched without a configured policy or mapping source. Present the two
  evidence sets separately and state that no mapping conclusion was established.
- Use friendly names only. Do not expose full or partial object identifiers, schema names,
  connection identifiers, or identifier-derived labels unless the operator explicitly requests
  raw identifiers.
- Never expose request IDs, client request IDs, correlation IDs, or raw service error messages,
  even when the operator asks for debugging output. Summarize only the operation, safe error
  category, HTTP status when useful, and corrective action.