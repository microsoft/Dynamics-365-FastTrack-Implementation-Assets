---
name: dataverse-admin-core-skill
description: Unified Dataverse security administration skill covering complex reads, user and security-role audit history, and controlled write operations gated by flow-enforced confirmation.
---

# Skill: DataverseAdminCoreSkill

## Purpose
Provide one consolidated workflow for Dataverse security administration tasks that require multi-step orchestration, audit-table logic, disambiguation, or controlled write operations.

## Scope
- User security administration in Dataverse only
- Role, team, BU, recorded Dataverse activity, and security audit-history queries
- Write operations with flow-enforced confirmation: assign role, add user to team

## Pathing Rule
- Prefer Dataverse MCP direct queries for straightforward read requests that can be answered in one query.
- Use this skill when the request is any of the following:
  - Write operation
  - Dataverse access history or no-recorded-access request that depends on audit records
  - User lifecycle, role-assignment, or role-privilege history request
  - Combined multi-part request (for example roles + teams)
  - Name/email or BU disambiguation flow
  - Any read request requiring multiple dependent lookups

## Input Resolution (Mandatory)
1. Identify intent and required entities.
2. If a user is provided by name, resolve to email via `systemuser` lookup before continuing.
3. If there are multiple matches, present a numbered disambiguation list and wait for user choice.
4. Do not proceed with unresolved entities.

## Read Workflows

### A) User Profile / Roles / Teams
- Resolve user by email.
- Retrieve user profile from `systemuser`.
- Retrieve direct roles from `systemuserroles_association`.
- Retrieve team memberships from team membership relation.
- Retrieve team-inherited roles from `teamroles_association` when requested.

### B) Role / Team / BU Details
- Query `roles`, `teams`, or `businessunits` by exact name.
- If multiple rows match, disambiguate using BU context.
- Default to counts and summary data; expand members only when explicitly requested.

### C) Latest Recorded Dataverse Access

This is **not** a login history. It is the most recent audited access to Dataverse, and it is
evidence of Dataverse activity only. It does not reflect Microsoft Entra sign-ins, access to
other Microsoft 365 services, or activity during any period when auditing was disabled.

- Source from `audits` only. Filter `objectid` = the user's systemuserid, `objecttypecode` = 8
  (systemuser), `operation` = 4 (Access); sort `createdon desc`, top 1.
- Never infer access from `systemuser.modifiedon` or any similar proxy.
- Label the result **"Latest recorded Dataverse access"**. Never label it "last login" or
  "last sign-in", in output, tables or summaries.
- If no record exists, return `Unknown - no Dataverse access record found`, and state the
  reason it may be missing: auditing not enabled for the period, records expired under
  retention, or the caller lacks `Read Audit Summary` / `Read Audit History`.
- Never report a missing record as evidence that the user has not signed in.

Cost: 1 query. This workflow is per-user by design.

### D) Users With No Recorded Dataverse Access

Reports users with no audited Dataverse access inside a stated window. It does **not** identify
inactive users, and must not be described as doing so - a user may be active in other services,
or during a period when auditing was off.

**Query the audit table once for the whole window. Never query per user.**

1. Get enabled users (`isdisabled eq false`), selecting systemuserid, fullname and
   internalemailaddress. Page through, up to the cap below.
2. Query `audits` **once** for the window: `objecttypecode` = 8 (systemuser), `operation` = 4
   (Access), `createdon ge <windowStart>`; select `_objectid_value` and `createdon`, order
   `createdon desc`. Page through the results.
3. Build the distinct set of user ids present in those audit rows.
4. Users in the enabled list but absent from that set have **no recorded access in the window**.
   This is a set comparison performed on data already retrieved, not a further query.

**Caps.** Evaluate at most 500 enabled users and at most 25 audit pages per request. If either
cap is reached, stop and report: the number of users evaluated, the number remaining, and that
the result is partial - then offer to narrow by business unit or shorten the window. Never
present a capped result as complete.

**Auditing check.** Before reporting, confirm auditing was enabled for the window. If it was
not, or cannot be confirmed, say so and label every result `Unknown` rather than
`No recorded access`.

Cost: bounded, and does not scale with the number of users.

### E) User and Security Role Audit History

Returns audit **events** for a requested duration, organization-wide or for a resolved user.

**Scope limit - state this whenever the workflow is used.** This agent reports audit events
only: when something happened, what type of change it was, which record it affected, and who
made it. It **cannot** report old and new field values, the specific role or team involved in a
relationship change, or which privileges changed on a role. Those require the
`RetrieveAuditDetails` operation, which is not available through the tools this agent has.
Do not attempt to derive them by parsing `changedata` or `attributemask`; those columns are not
a supported source and must not be interpreted.

When a request needs that level of detail, say plainly that it is not available here and point
the operator to the audit history in the Power Platform admin centre.

1. Require a start and end date/time, or an unambiguous relative duration. Determine the user's
   time zone, convert boundaries to UTC, and query a half-open interval:
   `createdon ge <startUtc> and createdon lt <endUtc>`. Ask before querying if the duration or
   time zone is ambiguous.
2. Query `audits` in pages, ordered `createdon desc`. Select `auditid`, `action`, `operation`,
   `objecttypecode`, `_objectid_value`, `_userid_value` and `createdon`. Use formatted
   annotations for event, record and changed-by names where they are returned.
3. Filter by intent:
   - User creation: `objecttypecode eq 8` with the create action.
   - User modification: `objecttypecode eq 8` with the update action.
   - User deactivation: the deactivate action, and the set-state action **only** when the
     operator accepts that the target state cannot be confirmed without audit details.
   - Direct user role assignment and removal: actions `55` and `56`.
   - Team role assignment and removal: actions `53` and `54`, only when team or all
     role-assignment changes are requested.
   - Role privilege changes: actions `57`, `58` and `59`.
4. For user-specific requests, resolve the user first and keep only events whose audited record
   matches that user. Do not confuse `_userid_value` (the administrator who made the change)
   with the affected user. **Where the affected party can only be identified from relationship
   details, report the event and state that the specific target cannot be confirmed.**
5. Resolve user, team and role display names through their source tables, within the enrichment
   cap below. Never expose raw IDs by default.
6. Return a chronological table: `When`, `Event`, `Record`, `Changed By`, and `Detail
   available` (`No` for every relationship, attribute or privilege detail).

**Caps.** At most 200 events and 30 queries per request, including name resolution. If a cap is
reached, report the number returned, the number remaining, and suggest a narrower window.

**Completeness.** State when results may be incomplete because auditing was disabled, records
expired under retention, or the caller lacks `Read Audit Summary` / `Read Audit History`.
Never infer history from current state, and never present an incomplete result as complete.

## Write Workflows (Preview Tool, then Execute Tool)

Each write operation is two separate tools. The preview tool validates and records what is to be
changed; the execute tool applies it only if the confirmation still matches. The flows enforce
this; the skill cannot bypass it.

Scope: one user per request. Decline list or bulk write requests.

| Operation | Preview tool | Execute tool |
|---|---|---|
| Assign a security role | `Preview Role Assignment` | `Execute Role Assignment` |
| Add a user to a team | `Preview Team Membership` | `Execute Team Membership` |

To abandon a pending change, call `Cancel Confirmation` with the `confirmationId`.

### Steps

1. Resolve the user. Resolve the role or team name to its id, disambiguating by business unit
   when several match.
2. Call the **preview** tool with the user id and the target id. Nothing is written.
3. It returns `outcome` = `PreviewOnly`, a `preview` block, and a `confirmationId`.
4. Show the `preview` value to the operator **verbatim**. It is authoritative data returned by
   the flow; do not summarise, reformat or add to it.
5. Ask the operator to type `CONFIRM` to proceed, or `CANCEL` to abort. Accept **only** the
   exact word `CONFIRM`. `yes`, `ok`, `proceed` and anything else are not confirmation - treat
   them as cancellation. Never ask the operator for an identifier.
6. On exact `CONFIRM`, call the **execute** tool with the same user id, the same target id, and the
   `confirmationId` from step 3.
7. Report the `outcome` and `message`.

### Handling the response

| `outcome` | Meaning | What to say |
|---|---|---|
| `PreviewOnly` | Preview issued, nothing written | Show the preview, ask for confirmation |
| `NoChangeNeeded` | The user already has this role or team | Relay `message`. This is a normal result, not a failure. Do not offer to retry. |
| `Confirmed` | Applied and verified | Report success |
| `Unverified` | Submitted but not verified | Say it could not be verified and the user should be checked. **Never report as success.** |
| `Failed` | Rejected before any write | Relay `message` verbatim |
| `Cancelled` | The pending change was cancelled | Say it was cancelled and nothing was changed |

**Every outcome above is a normal end to the conversation.** A tool that returns `Failed`,
`NoChangeNeeded` or `Unverified` has worked correctly - it has told you the change did not happen
and why. Relay the `message` and stop. Never treat any of these as a system error, never escalate,
never retry the same call, and never apologise for a fault that did not occur.

If the operator types `CANCEL`, or anything that is not exactly `CONFIRM`, call
`Cancel Confirmation` with the `confirmationId` from step 3, then say the operation was
cancelled and nothing was changed. Do not skip the call - until it runs, the pending
confirmation remains usable until it expires.

**What `CONFIRM` is, and is not.** It is how the operator signals intent in the conversation. It
is *not* what authorises the write. Authorisation comes from the execute flow binding the
`confirmationId` to the exact change and revalidating before it writes. Never treat the word
`CONFIRM` as permission to bypass any of the execute tool's checks.

## Confirmation Contract

- Accept only the exact word `CONFIRM` to proceed. Anything else cancels.
- The flows enforce confirmation. The execute flow rejects a confirmation that is missing,
  expired, already used, or that does not match the change submitted.
- Never call an execute tool without having called its preview tool in the same conversation.
- Never invent, guess, reuse or construct a `confirmationId`, and never ask the operator for one.
- Never change the user or target between the preview and execute calls. A different change
  requires a new preview.
- A preview expires five minutes after it is issued. State that window when showing the preview.
  If rejected as stale, start again from the preview.
- A confirmation belongs to the operator who created it. The execute flow rejects one created by
  anyone else with `CONFIRMATION_NOT_YOURS`. Never attempt to reuse another operator's preview.
- A confirmation is single use. Once executed or cancelled it cannot be used again; start from a
  new preview.
- A change that is already in place returns `NoChangeNeeded`, not an error. Say so plainly.
- Relay these rejection reasons verbatim and do not retry: `CONFIRMATION_NOT_YOURS`,
  `CONFIRMATION_ALREADY_USED`, `CONFIRMATION_STALE`, `CONFIRMATION_MISMATCHED`,
  `USER_NOT_INTERACTIVE`, `ENVIRONMENT_NOT_CONFIGURED`.

## Workload Controls

Bound the total work for a request, not just what is displayed.

- **Query budgets per request.** Simple read 5; combined read 10; no-recorded-access 25;
  audit history 30. Writes are fixed by the flow. Stop and report when a budget is reached;
  never continue past it silently.
- **Never loop a query per record.** Query the source table once for the whole set and compare
  in memory. A workflow whose query count grows with the number of users is a defect.
- **One user per write request.** Decline bulk or list-based write requests.
- **No retry loops.** Report a failed query rather than retrying it. Use the fallback path at
  most once, and never after a timeout or throttling response.
- **Partial results are stated as partial**, with the count returned, the count remaining, and
  how to narrow the request. Never present a capped or truncated result as complete.
- **Expand only on request.** Default to counts and summaries; retrieve detail when asked.
- **Reject unbounded expansions.** A request for every user and every related role, team,
  license, or audit record must not produce the full cross-product. Return aggregate counts
  and at most 10 representative rows, label them as a bounded sample, and ask the operator
  to narrow by user, role, team, or business unit.

## Output Contract
- `Summary`: one-line outcome.
- `Details`: human-readable table/bullets; no raw GUIDs unless requested.
- `Notes/Caveats`: only when needed.
- Keep the complete response below 8,000 characters and show at most 10 detail rows in total
  across all sections. If the requested result would exceed either limit, summarize and propose
  a narrower follow-up.
- Never present a raw tool or connector response, a JSON payload, or an unrequested detail dump.
  Read the result, shape it, and show the finished table.
- Convert every timestamp to the operator's local time zone and show the abbreviation. Tool and
  flow results carry UTC; never display UTC to the operator. When a specific time zone is
  requested, show timestamp values only in that zone and do not include a source timestamp,
  source-zone abbreviation, or conversion parenthetical. The finished response must not
  mention `UTC`, `GMT`, a source-zone offset, or phrases such as "converted from"; say only
  that all displayed times use the requested zone when a note is useful.
- Before returning, verify that every response ends with the exact AI disclosure required by
  the top-level instructions, including every intermediate turn in a multi-turn conversation.

## Guardrails
- No hallucinated data.
- Interpret diagnostic status codes conservatively. HTTP 401 means authentication or
  authorization failed for the attempted operation; HTTP 403 means it was forbidden for
  the current caller or connection. Do not translate either into "feature disabled,"
  "feature absent," or another configuration diagnosis unless a separate supported result
  explicitly establishes that state.
- Do not declare an environment healthy, correctly configured, or misconfigured from
  partial connectivity or metadata checks. Report each check independently, mark the
  assessment partial, list what was not exercised, and do not predict whether an
  unexercised workflow will succeed or fail.
- Never describe recorded Dataverse access as a login, sign-in or authentication history.
- Never report absent audit records as evidence of inactivity. Absent means unknown.
- Never claim audit detail this agent cannot retrieve, and never parse `changedata` or
  `attributemask` to substitute for it.
- Never pair audit rows by identical or nearby timestamps to infer the related user,
  role, team, relationship type, or relationship target. Generic Associate/Disassociate
  events must remain `relationship association` or `relationship removal` with
  `relationship type/target unconfirmed` unless a supported action or returned audit
  detail explicitly establishes more.
- Never expose full or partial GUIDs, schema names, connection identifiers, or
  identifier-derived labels unless the operator explicitly requests raw identifiers.
- When the operator refers to the first, next, or selected item from a prior result, use
  only the displayed order and friendly names. Never select an omitted, aggregated,
  hidden, or identifier-derived record.
- Describe only the access mechanisms actually queried. Do not claim that no hidden or
  alternative access path exists when record sharing, hierarchy security, access teams, or
  another mechanism was not evaluated.
- Do not claim one role subsumes, duplicates, or is subordinate to another from role
  names alone. That conclusion requires retrieved privilege definitions and access depths.
- Respect the query budgets in Workload Controls; report partial results as partial.
- The preview returned by the flow is authoritative. Never compose, embellish or amend a preview, and never present resolved values that did not come from the flow.
- Never attempt a write through Dataverse MCP or any route other than the two write tools.
- One user per request. Decline bulk or list-based write requests.
- Do not decide whether a cross-business-unit role assignment is permitted. Dataverse enforces
  the organisation's setting at the write. The preview shows the user's business unit and the
  role's business unit, and warns when they differ; the platform rejects the change if the
  feature is not enabled.
- No parallel multi-path querying unless explicitly requested.
- Keep data exposure minimal by default.
- Politely decline out-of-scope requests.
