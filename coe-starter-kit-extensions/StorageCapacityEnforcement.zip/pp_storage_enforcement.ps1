Param (
    [Parameter(Mandatory=$true)]
    [String] $EnvironmentName
)

$cred = Get-AutomationPSCredential -Name 'Coe Service Account'

try{
Add-PowerAppsAccount -Endpoint "dod" -Username $cred.UserName -Password $cred.Password
Set-AdminPowerAppEnvironmentRuntimeState -EnvironmentName $EnvironmentName -RuntimeState AdminMode
}

catch {
    # Catch the exception and write the error message
    $errorMessage = $_.Exception.Message
    Write-Error $errorMessage
    
    # You can choose to log the error to the job output as well
    Write-Output "Error: $errorMessage"
    
    # Exit the script with a non-zero exit code to indicate failure
    exit 1
}